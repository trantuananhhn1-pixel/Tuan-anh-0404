﻿param(
    [string]$OriginalPath = (Join-Path $PSScriptRoot "SinhVideoNgan_v1.13.0.exe"),
    [string]$OutputPath = (Join-Path $PSScriptRoot "SinhVideoNgan_v1.13.0_ThuyetMinh_BanThu.exe")
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Get-StreamSha256([System.IO.Stream]$Stream) {
    $Stream.Position = 0
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { $hash = $sha.ComputeHash($Stream) }
    finally { $sha.Dispose() }
    $Stream.Position = 0
    return [System.BitConverter]::ToString($hash).Replace('-', '').ToLowerInvariant()
}

$metadataPath = Join-Path $PSScriptRoot 'patch_metadata.json'
$suffixPath = Join-Path $PSScriptRoot 'narration_suffix.bin'
$metadata = Get-Content -LiteralPath $metadataPath -Raw -Encoding UTF8 | ConvertFrom-Json
$originalFull = [System.IO.Path]::GetFullPath($OriginalPath)
$outputFull = [System.IO.Path]::GetFullPath($OutputPath)
if ([string]::Equals($originalFull, $outputFull, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'The original EXE cannot be overwritten. Choose a different output path.'
}
if (Test-Path -LiteralPath $outputFull) {
    throw 'Output already exists. Move or rename it before trying again.'
}
if (-not (Test-Path -LiteralPath $originalFull -PathType Leaf)) {
    throw ('Original EXE not found: ' + $originalFull)
}
$outputDirectory = [System.IO.Path]::GetDirectoryName($outputFull)
if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
    throw 'The output directory does not exist.'
}
$temporary = Join-Path $outputDirectory ('.narration-' + [Guid]::NewGuid().ToString('N') + '.tmp')
$original = $null
$suffix = $null
$output = $null
try {
    $original = [System.IO.File]::Open($originalFull, [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    $suffix = [System.IO.File]::Open($suffixPath, [System.IO.FileMode]::Open,
        [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    if ($original.Length -ne [long]$metadata.original_bytes -or
        (Get-StreamSha256 $original) -ne $metadata.original_sha256) {
        throw 'Original EXE does not match the required version. No output was created.'
    }
    if ($suffix.Length -ne [long]$metadata.suffix_bytes -or
        (Get-StreamSha256 $suffix) -ne $metadata.suffix_sha256) {
        throw 'Patch data is damaged or incomplete. Download the complete package again.'
    }
    $cutoff = [long]$metadata.prefix_bytes
    $checksumOffset = [long]$metadata.checksum_offset
    [byte[]]$checksum = [System.Convert]::FromBase64String($metadata.checksum_base64)
    if ($cutoff -le 0 -or $cutoff -gt $original.Length -or
        $checksumOffset -lt 0 -or $checksumOffset + 4 -gt $cutoff -or
        $checksum.Length -ne 4 -or
        $cutoff + $suffix.Length -ne [long]$metadata.output_bytes) {
        throw 'Invalid patch metadata.'
    }
    $output = [System.IO.File]::Open($temporary, [System.IO.FileMode]::CreateNew,
        [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
    [byte[]]$buffer = New-Object byte[] (1024 * 1024)
    [long]$remaining = $cutoff
    while ($remaining -gt 0) {
        $requested = [int][Math]::Min([long]$buffer.Length, $remaining)
        $read = $original.Read($buffer, 0, $requested)
        if ($read -le 0) { throw 'Original EXE ended unexpectedly.' }
        $output.Write($buffer, 0, $read)
        $remaining -= $read
    }
    [void]$output.Seek($checksumOffset, [System.IO.SeekOrigin]::Begin)
    $output.Write($checksum, 0, $checksum.Length)
    [void]$output.Seek($cutoff, [System.IO.SeekOrigin]::Begin)
    $suffix.CopyTo($output)
    $output.Flush($true)
    if ($output.Length -ne [long]$metadata.output_bytes -or
        (Get-StreamSha256 $output) -ne $metadata.output_sha256) {
        throw 'Final EXE verification failed. The temporary output will be removed.'
    }
    $output.Dispose()
    $output = $null
    [System.IO.File]::Move($temporary, $outputFull)
    Write-Host 'Done. Original EXE unchanged.'
    Write-Host ('New trial EXE: ' + $outputFull)
    Write-Host ('Verified SHA-256: ' + $metadata.output_sha256)
    Write-Host 'Windows GUI and live online voice remain unverified.'
}
finally {
    if ($null -ne $output) { $output.Dispose() }
    if ($null -ne $suffix) { $suffix.Dispose() }
    if ($null -ne $original) { $original.Dispose() }
    if (Test-Path -LiteralPath $temporary) {
        Remove-Item -LiteralPath $temporary -Force
    }
}
