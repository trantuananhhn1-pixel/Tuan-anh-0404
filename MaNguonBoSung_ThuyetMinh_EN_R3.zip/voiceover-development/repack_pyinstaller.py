#!/usr/bin/env python3
"""Add an isolated runtime hook to an unsigned Python 3.12 PyInstaller EXE.

The original EXE is never executed or overwritten. Every original CArchive TOC
record and compressed payload is preserved verbatim. Hook source is executed in
its own module; it must perform its own installation (for example, install()).

Examples::
    python repack_pyinstaller.py build --input original.exe --hook extension.py \
        --output revised.exe --recompute-checksum
    python repack_pyinstaller.py verify --input original.exe --output revised.exe
"""
from __future__ import annotations

import argparse
import array
from dataclasses import dataclass
import hashlib
import json
import marshal
import os
from pathlib import Path
import re
import struct
import sys
import tempfile
import tokenize
import types
import zlib


MAGIC = b"MEI\x0c\x0b\x0a\x0b\x0e"
COOKIE = struct.Struct("!8sIIII64s")
TOC_HEADER = struct.Struct("!iIIIBc")
DEFAULT_HOOK = "pyi_rth_voiceover_extension"
DEFAULT_MODULE = "_voiceover_extension"
DEFAULT_TARGET = "video_gen_app"


class ArchiveError(ValueError):
    """Input cannot be repacked while preserving the supported invariants."""


@dataclass(frozen=True)
class Entry:
    name: str
    offset: int
    compressed_size: int
    size: int
    compressed: int
    typecode: bytes
    record: bytes


@dataclass(frozen=True)
class Archive:
    data: bytes
    start: int
    toc_offset: int
    toc_size: int
    python_version: int
    python_library: bytes
    entries: tuple[Entry, ...]

    def payload(self, entry: Entry) -> bytes:
        start = self.start + entry.offset
        return self.data[start:start + entry.compressed_size]


def parse_archive(data: bytes) -> Archive:
    if len(data) < COOKIE.size:
        raise ArchiveError("Input is shorter than a PyInstaller cookie")
    cookie_pos = len(data) - COOKIE.size
    magic, package_size, toc_offset, toc_size, pyver, pylib = COOKIE.unpack_from(data, cookie_pos)
    if magic != MAGIC:
        raise ArchiveError("A supported CArchive cookie must be at EOF; trailing data is unsupported")
    if package_size < COOKIE.size or package_size > len(data):
        raise ArchiveError("CArchive package size is out of bounds")
    start = len(data) - package_size
    if toc_offset + toc_size != package_size - COOKIE.size:
        raise ArchiveError("CArchive TOC does not end at the cookie")
    if toc_size == 0:
        raise ArchiveError("CArchive TOC is empty")
    cursor = start + toc_offset
    end = cursor + toc_size
    entries = []
    seen = set()
    while cursor < end:
        if end - cursor < TOC_HEADER.size + 1:
            raise ArchiveError("Truncated TOC header")
        length, offset, clen, ulen, compressed, typecode = TOC_HEADER.unpack_from(data, cursor)
        if length < TOC_HEADER.size + 1 or cursor + length > end:
            raise ArchiveError("Invalid TOC record size")
        record = data[cursor:cursor + length]
        encoded_name = record[TOC_HEADER.size:]
        if b"\0" not in encoded_name:
            raise ArchiveError("TOC filename is not NUL terminated")
        try:
            name = encoded_name.split(b"\0", 1)[0].decode("utf-8")
        except UnicodeDecodeError as error:
            raise ArchiveError("TOC filename is not UTF-8") from error
        if not name or name in seen:
            raise ArchiveError("Empty or duplicate TOC filename")
        seen.add(name)
        if compressed not in (0, 1):
            raise ArchiveError("Invalid CArchive compression flag")
        if offset + clen > toc_offset:
            raise ArchiveError("CArchive entry payload overlaps the TOC or is out of bounds")
        if not compressed and clen != ulen:
            raise ArchiveError("Uncompressed entry lengths disagree")
        entries.append(Entry(name, offset, clen, ulen, compressed, typecode, record))
        cursor += length
    return Archive(data, start, toc_offset, toc_size, pyver, pylib, tuple(entries))


def pe_checksum_offset(data: bytes) -> int:
    """Validate an unsigned PE and return its optional-header checksum offset."""
    if len(data) < 64 or data[:2] != b"MZ":
        raise ArchiveError("Input is not a PE executable")
    pe_pos = struct.unpack_from("<I", data, 60)[0]
    if pe_pos + 24 > len(data) or data[pe_pos:pe_pos + 4] != b"PE\0\0":
        raise ArchiveError("PE header is invalid")
    optional_size = struct.unpack_from("<H", data, pe_pos + 20)[0]
    optional = pe_pos + 24
    if optional + optional_size > len(data) or optional_size < 68:
        raise ArchiveError("PE optional header is truncated")
    magic = struct.unpack_from("<H", data, optional)[0]
    if magic == 0x20B:
        directory_count_offset, directory_start = 108, 112
    elif magic == 0x10B:
        directory_count_offset, directory_start = 92, 96
    else:
        raise ArchiveError("Unsupported PE optional-header format")
    if optional_size < directory_start:
        raise ArchiveError("PE data directory header is truncated")
    count = struct.unpack_from("<I", data, optional + directory_count_offset)[0]
    if count > 4:
        security_offset = directory_start + 4 * 8
        if optional_size < security_offset + 8:
            raise ArchiveError("PE security directory is truncated")
        certificate_address, certificate_size = struct.unpack_from("<II", data, optional + security_offset)
        if certificate_address or certificate_size:
            raise ArchiveError("Authenticode-signed EXEs are unsupported; repacking would invalidate their signature")
    return optional + 64


def update_pe_checksum(data: bytes) -> bytes:
    pos = pe_checksum_offset(data)
    mutable = bytearray(data)
    mutable[pos:pos + 4] = b"\0" * 4
    words = array.array("H")
    words.frombytes(mutable[:len(mutable) & ~1])
    if sys.byteorder != "little":
        words.byteswap()
    value = sum(words)
    if len(mutable) & 1:
        value += mutable[-1]
    value = (value & 0xFFFF) + (value >> 16)
    value = (value & 0xFFFF) + (value >> 16)
    value = (value & 0xFFFF) + len(mutable)
    struct.pack_into("<I", mutable, pos, value & 0xFFFFFFFF)
    return bytes(mutable)


def compile_isolated_hook(source: str, module_name: str = DEFAULT_MODULE) -> bytes:
    if not re.fullmatch(r"[A-Za-z_]\w*", module_name, flags=re.ASCII):
        raise ArchiveError("Hook module name must be a Python identifier")
    source_code = compile(source, module_name + ".py", "exec", dont_inherit=True)
    payload = marshal.dumps(source_code)
    # Lambda parameters remain local; no assignments enter the original __main__.
    wrapper = (
        "(lambda _module: ("
        f"__import__('sys').modules.__setitem__({module_name!r}, _module), "
        f"setattr(_module, '__file__', {module_name + '.py'!r}), "
        f"exec(__import__('marshal').loads({payload!r}), _module.__dict__)"
        f"))(__import__('types').ModuleType({module_name!r}))"
    )
    return marshal.dumps(compile(wrapper, "<voiceover-runtime-hook>", "exec", dont_inherit=True))


def build_bytes(original: bytes, hook_source: str, *, hook_name: str = DEFAULT_HOOK,
                module_name: str = DEFAULT_MODULE, target_name: str = DEFAULT_TARGET,
                recompute_checksum: bool = False) -> bytes:
    archive = parse_archive(original)
    checksum_pos = pe_checksum_offset(original)
    if checksum_pos + 4 > archive.start:
        raise ArchiveError("PE header overlaps the CArchive payload")
    runtime_version = sys.version_info.major * 100 + sys.version_info.minor
    if archive.python_version != runtime_version:
        raise ArchiveError(f"Compile with Python {archive.python_version // 100}.{archive.python_version % 100}; running {runtime_version}")
    if not re.fullmatch(r"[A-Za-z_]\w*", hook_name, flags=re.ASCII):
        raise ArchiveError("Hook TOC name must be an identifier")
    if any(entry.name == hook_name for entry in archive.entries):
        raise ArchiveError("Hook already exists in this executable")
    targets = [i for i, entry in enumerate(archive.entries) if entry.name == target_name]
    if len(targets) != 1 or archive.entries[targets[0]].typecode != b"s":
        raise ArchiveError("Expected exactly one named target runtime script")
    code = compile_isolated_hook(hook_source, module_name)
    compressed = zlib.compress(code, 9)
    encoded_name = hook_name.encode("utf-8") + b"\0"
    record_size = (TOC_HEADER.size + len(encoded_name) + 15) & ~15
    name_field = encoded_name.ljust(record_size - TOC_HEADER.size, b"\0")
    record = TOC_HEADER.pack(record_size, archive.toc_offset, len(compressed), len(code), 1, b"s") + name_field
    records = [entry.record for entry in archive.entries]
    records.insert(targets[0], record)
    toc = b"".join(records)
    toc_offset = archive.toc_offset + len(compressed)
    package_size = toc_offset + len(toc) + COOKIE.size
    if max(package_size, toc_offset, len(toc), len(code), len(compressed)) > 0xFFFFFFFF:
        raise ArchiveError("Result exceeds the CArchive 32-bit field limit")
    cookie = COOKIE.pack(MAGIC, package_size, toc_offset, len(toc), archive.python_version, archive.python_library)
    output = original[:archive.start + archive.toc_offset] + compressed + toc + cookie
    if recompute_checksum:
        output = update_pe_checksum(output)
    verify_bytes(original, output, hook_name=hook_name, target_name=target_name)
    return output


def verify_bytes(original: bytes, revised: bytes, *, hook_name: str = DEFAULT_HOOK,
                 target_name: str = DEFAULT_TARGET) -> dict:
    before, after = parse_archive(original), parse_archive(revised)
    checksum_pos = pe_checksum_offset(original)
    if pe_checksum_offset(revised) != checksum_pos:
        raise ArchiveError("PE header location changed")
    if before.start != after.start or before.python_version != after.python_version or before.python_library != after.python_library:
        raise ArchiveError("CArchive root or Python runtime changed")
    original_prefix = bytearray(original[:before.start + before.toc_offset])
    revised_prefix = bytearray(revised[:before.start + before.toc_offset])
    original_prefix[checksum_pos:checksum_pos + 4] = b"\0" * 4
    revised_prefix[checksum_pos:checksum_pos + 4] = b"\0" * 4
    if original_prefix != revised_prefix:
        raise ArchiveError("An original executable or CArchive payload byte changed")
    if len(after.entries) != len(before.entries) + 1:
        raise ArchiveError("Expected exactly one added archive entry")
    new_entries = [entry for entry in after.entries if entry.name == hook_name]
    if len(new_entries) != 1 or any(entry.name == hook_name for entry in before.entries):
        raise ArchiveError("Expected exactly one new named hook")
    hook = new_entries[0]
    if hook.typecode != b"s" or hook.compressed != 1 or hook.offset != before.toc_offset:
        raise ArchiveError("Hook is not the expected appended compressed runtime script")
    if after.toc_offset != before.toc_offset + hook.compressed_size:
        raise ArchiveError("Unexpected data between new hook and TOC")
    retained = [entry for entry in after.entries if entry.name != hook_name]
    for old, new in zip(before.entries, retained):
        if old.record != new.record or before.payload(old) != after.payload(new):
            raise ArchiveError(f"Original entry changed: {old.name}")
    names = [entry.name for entry in after.entries]
    if target_name not in names or names.index(hook_name) + 1 != names.index(target_name):
        raise ArchiveError("Hook does not immediately precede the target script")
    try:
        hook_data = zlib.decompress(after.payload(hook))
        if len(hook_data) != hook.size or not isinstance(marshal.loads(hook_data), types.CodeType):
            raise ArchiveError("Hook is not a correctly sized marshalled code object")
    except (zlib.error, ValueError, EOFError, TypeError) as error:
        raise ArchiveError("Hook payload is invalid") from error
    return {
        "original_sha256": hashlib.sha256(original).hexdigest(),
        "revised_sha256": hashlib.sha256(revised).hexdigest(),
        "original_entries_preserved": len(before.entries),
        "new_hook": hook_name,
        "before_script": target_name,
        "python_version": before.python_version,
        "checksum_changed": original[checksum_pos:checksum_pos + 4] != revised[checksum_pos:checksum_pos + 4],
    }


def build_file(input_path: Path, hook_path: Path, output_path: Path, **options) -> dict:
    input_path, hook_path, output_path = Path(input_path), Path(hook_path), Path(output_path)
    if input_path.resolve() == output_path.resolve():
        raise ArchiveError("The original executable cannot be overwritten")
    if output_path.exists() or output_path.is_symlink():
        raise FileExistsError(f"Output already exists: {output_path}")
    original = input_path.read_bytes()
    with tokenize.open(hook_path) as handle:
        source = handle.read()
    output = build_bytes(original, source, **options)
    report = verify_bytes(original, output, hook_name=options.get("hook_name", DEFAULT_HOOK), target_name=options.get("target_name", DEFAULT_TARGET))
    temporary = None
    try:
        descriptor, temporary = tempfile.mkstemp(prefix="." + output_path.name + ".", suffix=".tmp", dir=output_path.parent)
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(output)
            handle.flush()
            os.fsync(handle.fileno())
        # link() is atomic and refuses an existing destination, including races.
        os.link(temporary, output_path)
    finally:
        if temporary is not None:
            os.unlink(temporary)
    return report


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    subparsers = parser.add_subparsers(dest="command", required=True)
    for command in ("build", "verify"):
        subparser = subparsers.add_parser(command)
        subparser.add_argument("--input", required=True, type=Path)
        subparser.add_argument("--output", required=True, type=Path)
        subparser.add_argument("--hook-name", default=DEFAULT_HOOK)
        subparser.add_argument("--target-name", default=DEFAULT_TARGET)
        if command == "build":
            subparser.add_argument("--hook", required=True, type=Path)
            subparser.add_argument("--module-name", default=DEFAULT_MODULE)
            subparser.add_argument("--recompute-checksum", action="store_true")
    args = parser.parse_args(argv)
    try:
        if args.command == "build":
            report = build_file(args.input, args.hook, args.output,
                                hook_name=args.hook_name, module_name=args.module_name,
                                target_name=args.target_name, recompute_checksum=args.recompute_checksum)
        else:
            report = verify_bytes(args.input.read_bytes(), args.output.read_bytes(),
                                  hook_name=args.hook_name, target_name=args.target_name)
    except (ArchiveError, OSError, SyntaxError) as error:
        parser.exit(1, f"error: {error}\n")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
