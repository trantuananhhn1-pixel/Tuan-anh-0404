import hashlib
import marshal
from pathlib import Path
import struct
import sys
import tempfile
import unittest
import zlib

import repack_pyinstaller as repack


def fixture():
    """A tiny unsigned x64 PE prefix with a real CArchive record layout."""
    pe = bytearray(512)
    pe[:2] = b"MZ"
    struct.pack_into("<I", pe, 60, 128)
    pe[128:132] = b"PE\0\0"
    struct.pack_into("<H", pe, 148, 240)
    struct.pack_into("<H", pe, 152, 0x20B)
    struct.pack_into("<I", pe, 260, 16)
    records, data = [], bytearray()
    for name, raw, compressed, typ in [
        ("pyi_bootstrap", b"bootstrap", 1, b"s"),
        ("video_gen_app", b"original application", 1, b"s"),
        ("assets/picture.bin", b"asset\x00\x01", 0, b"x"),
    ]:
        payload = zlib.compress(raw) if compressed else raw
        encoded = name.encode() + b"\0"
        length = (repack.TOC_HEADER.size + len(encoded) + 15) & ~15
        record = repack.TOC_HEADER.pack(length, len(data), len(payload), len(raw), compressed, typ)
        records.append(record + encoded.ljust(length - repack.TOC_HEADER.size, b"\0"))
        data.extend(payload)
    toc = b"".join(records)
    cookie = repack.COOKIE.pack(repack.MAGIC, len(data) + len(toc) + repack.COOKIE.size,
                               len(data), len(toc), sys.version_info.major * 100 + sys.version_info.minor,
                               b"python312.dll".ljust(64, b"\0"))
    return bytes(pe) + data + toc + cookie


class RepackTests(unittest.TestCase):
    def test_build_preserves_all_existing_entries_and_order(self):
        original = fixture()
        revised = repack.build_bytes(original, "installed = True\n")
        report = repack.verify_bytes(original, revised)
        self.assertEqual(report["original_entries_preserved"], 3)
        self.assertFalse(report["checksum_changed"])
        names = [e.name for e in repack.parse_archive(revised).entries]
        self.assertEqual(names, ["pyi_bootstrap", repack.DEFAULT_HOOK, "video_gen_app", "assets/picture.bin"])
        self.assertEqual(hashlib.sha256(original).hexdigest(), report["original_sha256"])

    def test_isolated_hook_does_not_assign_main_globals(self):
        module_name = "_synthetic_voiceover_test"
        code = marshal.loads(repack.compile_isolated_hook("installed = 42\n", module_name))
        namespace = {"__name__": "__main__", "__builtins__": __builtins__, "sentinel": object()}
        before = dict(namespace)
        try:
            exec(code, namespace)
            self.assertEqual(namespace, before)
            self.assertEqual(sys.modules[module_name].installed, 42)
        finally:
            sys.modules.pop(module_name, None)

    def test_checksum_is_only_changed_prefix_field(self):
        original = fixture()
        revised = repack.build_bytes(original, "pass", recompute_checksum=True)
        self.assertTrue(repack.verify_bytes(original, revised)["checksum_changed"])
        self.assertEqual(repack.update_pe_checksum(revised), revised)

    def test_refuses_duplicate_hook(self):
        revised = repack.build_bytes(fixture(), "pass")
        with self.assertRaisesRegex(repack.ArchiveError, "already exists"):
            repack.build_bytes(revised, "pass")

    def test_refuses_missing_target(self):
        with self.assertRaisesRegex(repack.ArchiveError, "target runtime script"):
            repack.build_bytes(fixture(), "pass", target_name="missing")

    def test_refuses_wrong_python_version(self):
        original = bytearray(fixture())
        struct.pack_into("!I", original, len(original) - repack.COOKIE.size + 20, 311)
        with self.assertRaisesRegex(repack.ArchiveError, "Compile with Python"):
            repack.build_bytes(bytes(original), "pass")

    def test_refuses_signed_executable(self):
        original = bytearray(fixture())
        struct.pack_into("<II", original, 152 + 112 + 4 * 8, 500, 10)
        with self.assertRaisesRegex(repack.ArchiveError, "Authenticode"):
            repack.build_bytes(bytes(original), "pass")

    def test_refuses_truncated_or_trailing_data(self):
        for corrupt in [fixture()[:-1], fixture() + b"extra", b"short"]:
            with self.subTest(size=len(corrupt)), self.assertRaises(repack.ArchiveError):
                repack.parse_archive(corrupt)

    def test_refuses_out_of_bounds_payload(self):
        original = bytearray(fixture())
        archive = repack.parse_archive(original)
        struct.pack_into("!I", original, archive.start + archive.toc_offset + 4, 0xFFFFFFFF)
        with self.assertRaisesRegex(repack.ArchiveError, "out of bounds"):
            repack.parse_archive(bytes(original))

    def test_refuses_invalid_record_size(self):
        original = bytearray(fixture())
        archive = repack.parse_archive(original)
        struct.pack_into("!i", original, archive.start + archive.toc_offset, 1)
        with self.assertRaisesRegex(repack.ArchiveError, "record size"):
            repack.parse_archive(bytes(original))

    def test_detects_original_payload_tampering(self):
        original = fixture()
        revised = bytearray(repack.build_bytes(original, "pass"))
        revised[repack.parse_archive(original).start] ^= 1
        with self.assertRaisesRegex(repack.ArchiveError, "payload byte changed"):
            repack.verify_bytes(original, bytes(revised))

    def test_atomic_output_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            original, hook, output = root / "original.exe", root / "hook.py", root / "new.exe"
            original.write_bytes(fixture())
            initial = original.read_bytes()
            hook.write_text("installed = True\n")
            report = repack.build_file(original, hook, output)
            self.assertTrue(output.exists())
            self.assertEqual(original.read_bytes(), initial)
            self.assertEqual(report, repack.verify_bytes(initial, output.read_bytes()))
            with self.assertRaises(FileExistsError):
                repack.build_file(original, hook, output)
            with self.assertRaisesRegex(repack.ArchiveError, "cannot be overwritten"):
                repack.build_file(original, hook, original)
            self.assertEqual(sorted(p.name for p in root.iterdir()), ["hook.py", "new.exe", "original.exe"])


if __name__ == "__main__":
    unittest.main()
