import sys
import types
import unittest
from unittest.mock import patch

from build_release import make_hook


class FakeRoot:
    def __truediv__(self, name):
        return self

    def read_text(self, **kwargs):
        return "def install_ui():\n    pass\ndef install_audio():\n    pass\n"


class ReleaseHookTests(unittest.TestCase):
    def test_runtime_modules_install_in_order(self):
        source = make_hook(FakeRoot())
        with patch.dict(sys.modules), patch.object(sys, "argv", ["tool.exe"]):
            exec(compile(source, "hook.py", "exec"), {})
            for name in ["narration_voices", "narration_tts", "narration_ui", "narration_audio"]:
                self.assertIsInstance(sys.modules[name], types.ModuleType)

    def test_cookie_worker_path_does_not_import_or_patch_application(self):
        source = make_hook(FakeRoot())
        with patch.dict(sys.modules), patch.object(sys, "argv", ["tool.exe", "--cookie-worker"]):
            for name in ["narration_voices", "narration_tts", "narration_ui", "narration_audio"]:
                sys.modules.pop(name, None)
            exec(compile(source, "hook.py", "exec"), {})
            for name in ["narration_voices", "narration_tts", "narration_ui", "narration_audio"]:
                self.assertNotIn(name, sys.modules)


if __name__ == "__main__":
    unittest.main()
