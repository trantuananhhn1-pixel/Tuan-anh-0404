import unittest

from narration_voices import DEFAULT_VOICE, VOICE_PRESETS, resolve_voice


class VoiceCatalogTests(unittest.TestCase):
    def test_ten_unique_english_voices_with_five_of_each_gender(self):
        self.assertEqual(len(VOICE_PRESETS), 10)
        self.assertEqual(len({v["id"] for v in VOICE_PRESETS}), 10)
        self.assertEqual(len({v["label"] for v in VOICE_PRESETS}), 10)
        self.assertEqual(sum(v["gender"] == "Female" for v in VOICE_PRESETS), 5)
        self.assertEqual(sum(v["gender"] == "Male" for v in VOICE_PRESETS), 5)
        self.assertTrue(all(v["locale"].startswith("en-") for v in VOICE_PRESETS))

    def test_old_default_and_display_labels_resolve_to_same_voice(self):
        self.assertEqual(resolve_voice()["id"], "en-US-JennyNeural")
        self.assertEqual(resolve_voice("")["id"], DEFAULT_VOICE)
        for voice in VOICE_PRESETS:
            self.assertEqual(resolve_voice(voice["label"])["id"], voice["id"])

    def test_unlisted_voice_cannot_inject_an_ssml_name(self):
        for bad in ["<voice>", "en-US-UnknownNeural", 123]:
            with self.assertRaises(ValueError):
                resolve_voice(bad)
        copy = resolve_voice()
        copy["id"] = "changed"
        self.assertEqual(resolve_voice()["id"], DEFAULT_VOICE)


if __name__ == "__main__":
    unittest.main()
