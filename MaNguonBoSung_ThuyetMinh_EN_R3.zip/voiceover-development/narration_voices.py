"""The ten selectable English narrator voices; Jenny remains the R2 default."""

DEFAULT_VOICE = "en-US-JennyNeural"

VOICE_PRESETS = (
    {"id": "en-US-JennyNeural", "label": "Jenny — Nữ · Mỹ", "locale": "en-US", "gender": "Female"},
    {"id": "en-US-AriaNeural", "label": "Aria — Nữ · Mỹ", "locale": "en-US", "gender": "Female"},
    {"id": "en-US-AnaNeural", "label": "Ana — Nữ · Mỹ", "locale": "en-US", "gender": "Female"},
    {"id": "en-GB-SoniaNeural", "label": "Sonia — Nữ · Anh", "locale": "en-GB", "gender": "Female"},
    {"id": "en-AU-NatashaNeural", "label": "Natasha — Nữ · Úc", "locale": "en-AU", "gender": "Female"},
    {"id": "en-US-GuyNeural", "label": "Guy — Nam · Mỹ", "locale": "en-US", "gender": "Male"},
    {"id": "en-US-ChristopherNeural", "label": "Christopher — Nam · Mỹ", "locale": "en-US", "gender": "Male"},
    {"id": "en-US-EricNeural", "label": "Eric — Nam · Mỹ", "locale": "en-US", "gender": "Male"},
    {"id": "en-GB-RyanNeural", "label": "Ryan — Nam · Anh", "locale": "en-GB", "gender": "Male"},
    {"id": "en-AU-WilliamNeural", "label": "William — Nam · Úc", "locale": "en-AU", "gender": "Male"},
)


def resolve_voice(value=None):
    candidate = DEFAULT_VOICE if value is None or value == "" else value
    for preset in VOICE_PRESETS:
        if candidate in (preset["id"], preset["label"]):
            return dict(preset)
    raise ValueError("Giọng đọc không hợp lệ. Vui lòng chọn một giọng trong danh sách.")


def voice_label(value=None):
    return resolve_voice(value)["label"]
