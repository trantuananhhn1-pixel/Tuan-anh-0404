import random
import json
import marshal
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import types
import unittest
from unittest.mock import Mock

from narration_planner import install_planner, plan_sections


class BoundaryRandom:
    def __init__(self, count, upper):
        self.count = count
        self.upper = upper

    def choice(self, values):
        return self.count

    def randint(self, low, high):
        if low > high:
            raise AssertionError("infeasible segment")
        return high if self.upper else low


class PlannerTests(unittest.TestCase):
    def assert_valid_plan(self, sections, source):
        self.assertIn(len(sections), (4, 5))
        lengths = []
        for start, end in sections:
            self.assertGreaterEqual(start, 0)
            self.assertLessEqual(end, source)
            length = round((end - start) * 1000)
            self.assertGreaterEqual(length, 5000)
            self.assertLessEqual(length, 8000)
            lengths.append(length)
        self.assertGreaterEqual(sum(lengths), 20000)
        self.assertLessEqual(sum(lengths), 30000)

    def test_seeded_plans_meet_all_three_constraints(self):
        counts = set()
        rng = random.Random(20261101)
        for source in [5, 5.001, 5.999, 7.999, 8, 10, 120, 3600.125]:
            for unused in range(300):
                sections = plan_sections(source, rng)
                self.assert_valid_plan(sections, source)
                counts.add(len(sections))
        self.assertEqual(counts, {4, 5})

    def test_exact_feasible_boundaries_never_leave_a_short_tail(self):
        for count in (4, 5):
            for upper in (False, True):
                for source in (5, 5.001, 7.999, 8, 120):
                    with self.subTest(count=count, upper=upper, source=source):
                        sections = plan_sections(source, BoundaryRandom(count, upper))
                        self.assert_valid_plan(sections, source)
                        self.assertEqual(len(sections), count)
                        total = round(sum(end - start for start, end in sections) * 1000)
                        expected = (min(30000, count * min(8000, int(source * 1000)))
                                    if upper else count * 5000)
                        self.assertEqual(total, expected)

    def test_invalid_or_too_short_sources_fail_clearly(self):
        for source in (None, "bad", 0, -1, float("nan"), float("inf"), 4.999):
            with self.subTest(source=source), self.assertRaises(ValueError):
                plan_sections(source, random.Random(1))

    def test_installer_preserves_other_features_and_is_idempotent(self):
        old_plan = Mock()
        old_many, old_images = object(), object()
        source = Mock(return_value=("file.mp4", 50))
        generator = types.SimpleNamespace(
            plan_sections=old_plan, random=random.Random(2),
            plan_many=old_many, build_image_video=old_images,
            _obtain_source=source, DEFAULT_PAN_SECONDS=5.0, MAX_SIMILARITY=0.3,
        )
        install_planner(generator)
        wrapper = generator.plan_sections
        install_planner(generator)
        self.assertIs(generator.plan_sections, wrapper)
        self.assertIs(generator.plan_many, old_many)
        self.assertIs(generator.build_image_video, old_images)
        self.assertEqual(generator.DEFAULT_PAN_SECONDS, 5.0)
        self.assertEqual(generator.MAX_SIMILARITY, 0.3)
        self.assert_valid_plan(generator.plan_sections(50), 50)
        old_plan.assert_not_called()
        logs = []
        self.assertEqual(generator._obtain_source("url", "tmp", "ffmpeg", logs.append), ("file.mp4", 50))
        self.assertEqual(len(logs), 1)
        self.assertIn("Cắt video R4", logs[0])
        source.return_value = ("short.mp4", 4.5)
        with self.assertRaisesRegex(ValueError, "ngắn hơn 5"):
            generator._obtain_source("url", "tmp", "ffmpeg", logs.append)


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "FFmpeg required")
class OriginalRenderTests(unittest.TestCase):
    def test_original_ffmpeg_renderer_follows_plan_with_frame_boundary_rounding(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source.mp4"
            subprocess.run([
                "ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin",
                "-f", "lavfi", "-i", "testsrc2=size=160x120:rate=25:duration=40",
                "-c:v", "libx264", "-preset", "ultrafast", "-threads", "2", str(source),
            ], check=True, capture_output=True, timeout=60)
            baseline = Path(__file__).resolve().parents[1] / "extracted/app-bytecode/core/video_generator.pyc"
            module = marshal.loads(baseline.read_bytes()[16:])
            code = next(c for c in module.co_consts
                        if isinstance(c, types.CodeType) and c.co_name == "_build_main")
            commands = []

            def run(command):
                commands.append(command)
                subprocess.run(command, check=True, capture_output=True, timeout=60)

            namespace = {
                "os": os, "_run": run,
                "_venc_args": lambda exe, cpu_crf=18: [
                    "-c:v", "libx264", "-preset", "ultrafast", "-threads", "2",
                    "-crf", str(cpu_crf), "-filter_complex_threads", "1",
                ],
            }
            render = types.FunctionType(code, namespace, "_build_main")
            for index, rng in enumerate([
                BoundaryRandom(4, False), BoundaryRandom(5, True), random.Random(19),
            ]):
                with self.subTest(render=index):
                    sections = plan_sections(40, rng)
                    folder = root / str(index)
                    folder.mkdir()
                    output = render(str(source), sections, "ffmpeg", str(folder))
                    response = subprocess.run([
                        "ffprobe", "-v", "error", "-show_entries", "format=duration",
                        "-of", "json", output,
                    ], check=True, capture_output=True, timeout=30)
                    seconds = float(json.loads(response.stdout)["format"]["duration"])
                    # Original FFmpeg trimming rounds each cut to source frames;
                    # e.g. a 20.000s plan encodes as 19.960s at 25fps. Preserve
                    # that renderer while bounding its error by one frame/cut.
                    frame_tolerance = len(sections) / 25
                    self.assertGreaterEqual(seconds, 20 - frame_tolerance)
                    self.assertLessEqual(seconds, 30 + frame_tolerance)
                    planned = sum(end - start for start, end in sections)
                    self.assertAlmostEqual(seconds, planned, delta=frame_tolerance)
                    graph = commands[-1][commands[-1].index("-filter_complex") + 1]
                    self.assertIn(f"concat=n={len(sections)}:v=1:a=0", graph)


if __name__ == "__main__":
    unittest.main()
