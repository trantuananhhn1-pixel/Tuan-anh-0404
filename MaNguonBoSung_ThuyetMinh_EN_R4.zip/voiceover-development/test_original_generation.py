"""Exercise narration hooks with selected, reviewed original function bytecode.

The original module body is never executed. Network, image preparation and video
rendering are replaced; original scheduling, naming, caching and stats run here.
"""
from pathlib import Path
import builtins
import dis
import marshal
import os
import random
import re
import shutil
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

import narration_audio as audio
import narration_tts as tts
import narration_ui as ui
from narration_voices import DEFAULT_VOICE, voice_label
import pandas as pd


BYTECODE = Path(__file__).resolve().parents[1] / "extracted/app-bytecode"


def code_from(module):
    return marshal.loads((BYTECODE / (module + ".pyc")).read_bytes()[16:])


def function_code(container, name):
    return next(c for c in container.co_consts
                if isinstance(c, types.CodeType) and c.co_name == name)


class OriginalGenerationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.output = self.root / "output"
        self.logs, self.progress, self.renders, self.sources, self.plans = [], [], [], [], []
        self.module_code = code_from("core/video_generator")
        self.generator = types.SimpleNamespace(
            __builtins__=builtins.__dict__, os=os, re=re, shutil=shutil,
            tempfile=tempfile, random=random.Random(12345),
            TOTAL_MIN=15.0, TOTAL_MAX=30.0, SECTION_MIN=6.0, SECTION_MAX=10.0,
            MAX_SIMILARITY=0.3, PAN_DIRECTIONS=("ltr", "rtl", "alternate"),
            MAX_PAN_OFFSET=0.45, DEFAULT_PAN_SECONDS=5.0, IMAGE_NAME_MAX=150,
            _FNAME_FORBIDDEN=set('\\/:*?"<>|'),
            _WINDOWS_FORBIDDEN=set('\\/:*?"<>|'),
            _ffmpeg_exe=lambda: "fake-ffmpeg",
            _arrow_default_path=lambda: None,
            _available_random_fonts=lambda: [], _detect_hw_encoder=lambda exe: None,
        )
        for name in [
            "plan_sections", "_dur", "overlap_ratio", "plan_many", "_local_path",
            "_resolve_dir", "_safe_filename", "_output_name", "_dedupe_name",
            "_image_output_base", "_image_orders", "_pan_directions",
            "build_one_video", "build_image_video", "generate_all",
        ]:
            setattr(self.generator, name, types.FunctionType(
                function_code(self.module_code, name), self.generator.__dict__, name,
            ))
        # These are the defaults visible in the reviewed original MAKE_FUNCTION.
        self.generator.generate_all.__defaults__ = (
            None, None, None, None, None, 1080, False, "ltr", 0.0, 0.0, 5.0,
        )
        self.generator._sanitize_folder = types.FunctionType(
            function_code(code_from("core/channel_downloader"), "_sanitize_folder"),
            self.generator.__dict__, "_sanitize_folder",
        )
        original_plan = self.generator.plan_many

        def plan(*args, **kwargs):
            self.plans.append(list(kwargs.get("existing", [])))
            return original_plan(*args, **kwargs)

        self.generator.plan_many = plan

        def source(url, cache, ffmpeg, log, max_h):
            self.sources.append(url)
            path = Path(cache) / "source.mp4"
            path.write_bytes(b"source")
            return str(path), 1000.0

        def main(src, sections, ffmpeg, temporary):
            path = Path(temporary) / "main.mp4"
            path.write_bytes(b"main")
            return str(path)

        def pan_main(images, directions, seconds, ffmpeg, temporary):
            return main(None, None, ffmpeg, temporary)

        def prepare_images(image_dir, cache, left, right, seconds, log):
            if not Path(image_dir).is_dir():
                raise RuntimeError("missing image source")
            return [str(Path(image_dir) / f"image_{i}.jpg") for i in range(3)]

        def finish(main, title_big, title_small, arrow, out_path, ffmpeg_exe, tmp,
                   style_random):
            self.renders.append((title_big, Path(out_path)))
            Path(out_path).write_bytes(b"silent-render")

        self.generator._obtain_source = source
        self.generator._build_main = main
        self.generator._build_pan_main = pan_main
        self.generator._prepare_image_dir = prepare_images
        self.generator._finish_video = finish
        self.presenter = types.SimpleNamespace(generate_all=self.generator.generate_all)
        self.synth = Mock(side_effect=lambda text, path, **kw: Path(path).write_bytes(b"MP3"))
        self.mux_calls = []

        def mux(video, speech, output, *args):
            self.mux_calls.append((Path(video), Path(speech), Path(output)))
            Path(output).write_bytes(b"narrated-render")

        self.mux_patch = patch.object(audio, "mux_narration", side_effect=mux)
        self.mux_patch.start()
        self.addCleanup(self.mux_patch.stop)
        audio.install_audio(self.generator, self.presenter, self.synth)

    def row(self, name, narration="", count=1, **kwargs):
        return dict(folder="same folder", youtube_url="same-source", title_big=name,
                    title_small="unchanged small title", filename=name, count=count,
                    narration=narration, **kwargs)

    def generate(self, rows):
        return self.presenter.generate_all(
            rows=rows, output_root=str(self.output), on_log=self.logs.append,
            on_progress=lambda done, total: self.progress.append((done, total)),
        )

    def test_original_video_loop_keeps_narration_aligned_and_source_cached(self):
        stats = self.generate([
            self.row("first", "Lời đọc thứ nhất", 2),
            self.row("blank", "", 1),
            self.row("last", "Lời đọc cuối", 2),
        ])
        self.assertEqual(stats, dict(rows=3, videos=5, errors=0))
        self.assertEqual(self.sources, ["same-source"])
        self.assertEqual([len(p) for p in self.plans], [0, 2, 3])
        self.assertEqual([c.args[0] for c in self.synth.call_args_list],
                         ["Lời đọc thứ nhất", "Lời đọc cuối"])
        self.assertEqual([c[2].name for c in self.mux_calls],
                         ["first_1.mp4", "first_2.mp4", "last_1.mp4", "last_2.mp4"])
        self.assertEqual((self.output / "same folder/blank.mp4").read_bytes(), b"silent-render")
        self.assertEqual(self.progress, [(i, 5) for i in range(1, 6)])
        self.assertIsNone(getattr(audio._local, "state", None))

    def test_original_image_loop_and_video_loop_share_row_context(self):
        images = self.root / "images"
        images.mkdir()
        rows = [self.row("pictures", "Đọc ảnh", 2, image_dir=str(images)),
                self.row("video", "Đọc video"), self.row("blank", "")]
        stats = self.generate(rows)
        self.assertEqual(stats, dict(rows=3, videos=4, errors=0))
        self.assertEqual([c.args[0] for c in self.synth.call_args_list], ["Đọc ảnh", "Đọc video"])
        self.assertEqual([c[2].name for c in self.mux_calls],
                         ["pictures_1.mp4", "pictures_2.mp4", "video.mp4"])
        self.assertEqual(self.sources, ["same-source"])
        self.assertEqual(self.progress[-1], (4, 4))

    def test_original_failure_stats_continue_and_do_not_leave_silent_narration(self):
        self.synth.side_effect = RuntimeError("speech service unavailable")
        stats = self.generate([self.row("failed", "Lời đọc", 2), self.row("plain", "")])
        self.assertEqual(stats, dict(rows=2, videos=1, errors=2))
        self.synth.assert_called_once()
        self.assertEqual(self.mux_calls, [])
        self.assertEqual([title for title, path in self.renders], ["plain"])
        self.assertEqual(sorted(p.name for p in (self.output / "same folder").glob("*.mp4")),
                         ["plain.mp4"])
        self.assertEqual(self.progress, [(1, 3), (2, 3), (3, 3)])

    def test_original_presenter_run_accepts_existing_config_without_ffmpeg_argument(self):
        presenter_code = code_from("presenters/video_gen_presenter")
        cls = function_code(presenter_code, "VideoGenPresenter")
        run = types.FunctionType(function_code(cls, "_run"), self.presenter.__dict__, "_run")
        self.presenter._stop_flag = False
        self.presenter._on_complete = Mock()
        self.presenter._log = self.logs.append
        self.presenter.view = types.SimpleNamespace(set_progress=Mock())
        self.presenter._ui = lambda callback, *args: callback(*args)
        run(self.presenter, dict(rows=[self.row("presented", "Xin chào")],
                                 output_root=str(self.output)))
        self.assertEqual(len(self.mux_calls), 1)
        self.assertEqual(self.mux_calls[0][2].name, "presented.mp4")
        self.presenter._on_complete.assert_called_once()
        self.assertTrue(any("1 video, 0 lỗi" in message for message in self.logs), self.logs)
        self.assertFalse(any(message.startswith("❌ Lỗi:") for message in self.logs), self.logs)

    def _assert_excel_narration_pipeline(self, selected_voice=None):
        sentence = (
            "Discover Busch Gardens Tampa Bay in Florida, where thrilling roller coasters, "
            "incredible wildlife, and exciting family attractions create unforgettable adventures."
        )
        source_code = code_from("core/sheet_source")
        instructions = list(dis.get_instructions(source_code))
        cols_end = next(i for i, item in enumerate(instructions)
                        if item.opname == "STORE_NAME" and item.argval == "GEN_COLS")
        aliases_end = next(i for i, item in enumerate(instructions)
                           if item.opname == "STORE_NAME" and item.argval == "_GEN_ALIASES")
        # Recover the original literal metadata without executing module setup.
        columns = next(value for value in source_code.co_consts
                       if isinstance(value, tuple) and value[:2] == ("folder", "youtube_url")
                       and len(value) == 7)
        alias_sets = [item.argval for item in instructions[cols_end:aliases_end]
                      if item.opname == "LOAD_CONST" and isinstance(item.argval, frozenset)]
        self.assertEqual(len(alias_sets), len(columns))
        aliases = dict(zip(columns, alias_sets))
        normalizer = types.FunctionType(
            function_code(source_code, "_normalize_gen_df"),
            dict(pd=pd, GEN_COLS=list(columns), _GEN_ALIASES=aliases),
        )
        normalize = ui._make_normalizer(normalizer, columns, aliases)
        spreadsheet = self.root / "duplicate-narration.xlsx"
        pd.DataFrame([
            ["same folder", "same-source", "Busch Gardens", "Original small title",
             "busch_gardens", 1, "", "", sentence],
        ], columns=[
            "Tên folder", "Link Video", "Tiêu đề to", "Tiêu đề nhỏ", "Tên file",
            "Số lượng video đầu ra", "Thư mục ảnh", "Lời thuyết minh", "Lời thuyết minh",
        ]).to_excel(spreadsheet, index=False)
        imported = pd.read_excel(spreadsheet)
        self.assertEqual(imported.columns[-2:].tolist(),
                         ["Lời thuyết minh", "Lời thuyết minh.1"])
        normalized = normalize(imported)

        raw_table = types.SimpleNamespace(
            set_sheet_data=lambda rows, **kwargs: setattr(raw_table, "rows", rows),
            get_sheet_data=lambda: raw_table.rows,
            headers=lambda headers: None,
        )
        table_namespace = dict(pd=pd, COLS=list(columns) + ["narration"],
                               HEADERS_VI=list(columns) + ["Lời thuyết minh"])
        table_code = function_code(code_from("views/components/gen_sheet"), "GenSheet")
        table = types.SimpleNamespace(sheet=raw_table)
        load_df = types.FunctionType(function_code(table_code, "load_df"), table_namespace)
        getter = types.FunctionType(function_code(table_code, "to_df"), table_namespace)
        getter = ui._make_table_getter(getter, columns)
        table.to_df = types.MethodType(getter, table)
        load_df(table, normalized)

        window_code = code_from("views/video_gen_window")
        window_class = function_code(window_code, "VideoGenWindow")
        window_namespace = dict(QUALITY_OPTIONS={"Full HD": 1080}, PAN_OPTIONS={"Left": "ltr"})
        window_namespace["_parse_float"] = types.FunctionType(
            function_code(window_code, "_parse_float"), window_namespace,
        )
        original_config_getter = types.FunctionType(
            function_code(window_class, "get_run_config"), window_namespace,
        )
        config_getter = ui._make_config_getter(original_config_getter, columns)

        def value(item):
            return types.SimpleNamespace(get=lambda: item)

        view = types.SimpleNamespace(
            gen_sheet=table, txt_output=value(str(self.output)),
            opt_quality=value("Full HD"), chk_random_style=value(False),
            opt_pan_dir=value("Left"), txt_pan_left=value("0"),
            txt_pan_right=value("0"), txt_pan_seconds=value("5"), set_progress=Mock(),
        )
        if selected_voice is not None:
            view.opt_narration_voice = value(voice_label(selected_voice))
        config = config_getter(view)
        expected_voice = selected_voice or DEFAULT_VOICE
        self.assertEqual(config["rows"][0]["narration"], sentence)
        self.assertEqual(config["narration_voice"], expected_voice)
        self.assertEqual(config["rows"][0]["narration_voice"], expected_voice)
        baseline = original_config_getter(ui._ViewSnapshot(
            view, table.to_df().reindex(columns=columns, fill_value=""),
        ))
        self.assertEqual(
            {key: item for key, item in config.items()
             if key not in ("rows", "narration_voice")},
            {key: item for key, item in baseline.items() if key != "rows"},
        )
        self.assertEqual(
            [{key: item for key, item in row.items()
              if key not in ("narration", "narration_voice")}
             for row in config["rows"]],
            baseline["rows"],
        )

        class SynchronousThread:
            def __init__(self, target, args, daemon):
                self.target, self.args = target, args

            def start(self):
                self.target(*self.args)

            def is_alive(self):
                return False

        results = []
        hooked_generate = self.presenter.generate_all

        def observe_generation(*args, **kwargs):
            stats = hooked_generate(*args, **kwargs)
            results.append(stats)
            return stats

        self.presenter.generate_all = observe_generation
        self.presenter.threading = types.SimpleNamespace(Thread=SynchronousThread)
        self.presenter._thread = None
        self.presenter._log = self.logs.append
        self.presenter.view = view
        self.presenter._ui = lambda callback, *args: callback(*args)
        presenter_class = function_code(code_from("presenters/video_gen_presenter"), "VideoGenPresenter")
        for name in ("_run", "start_generate"):
            method = types.FunctionType(function_code(presenter_class, name), self.presenter.__dict__)
            setattr(self.presenter, name, types.MethodType(method, self.presenter))
        completed = Mock()
        self.presenter.start_generate(config, completed)

        self.synth.assert_called_once()
        self.assertEqual(self.synth.call_args.args[0], sentence)
        self.assertEqual(self.synth.call_args.kwargs["voice"], expected_voice)
        self.assertEqual(tts.VOICE, "en-US-JennyNeural")
        self.assertEqual(results, [dict(rows=1, videos=1, errors=0)])
        self.assertEqual(len(self.mux_calls), 1)
        self.assertEqual(self.mux_calls[0][2].name, "busch_gardens.mp4")
        self.assertEqual(self.mux_calls[0][2].read_bytes(), b"narrated-render")
        self.assertTrue(any("Thuyết minh R" in message and "1/1 dòng có lời đọc" in message
                            for message in self.logs), self.logs)
        self.assertTrue(any(voice_label(expected_voice) in message for message in self.logs), self.logs)
        completed.assert_called_once()

    def test_duplicate_excel_narration_reaches_original_ui_presenter_and_generation(self):
        self._assert_excel_narration_pipeline()

    def test_selected_male_voice_survives_original_config_presenter_and_generation(self):
        self._assert_excel_narration_pipeline(selected_voice="en-GB-RyanNeural")

    def test_requested_link_planner_preserves_original_batch_cache_and_selected_voice(self):
        from narration_planner import install_planner

        original_many = self.generator.plan_many
        original_main = self.generator._build_main
        sections_rendered = []

        def capture_main(source, sections, ffmpeg, temporary):
            sections_rendered.append(list(sections))
            return original_main(source, sections, ffmpeg, temporary)

        self.generator._build_main = capture_main
        install_planner(self.generator)
        self.assertIs(self.generator.plan_many, original_many)
        self.assertEqual(self.generator.MAX_SIMILARITY, 0.3)
        stats = self.generate([
            self.row("first", "Selected male narrator.", 2,
                     narration_voice="en-GB-RyanNeural"),
            self.row("next", "Selected male narrator.", 3,
                     narration_voice="en-GB-RyanNeural"),
        ])

        self.assertEqual(stats, dict(rows=2, videos=5, errors=0))
        self.assertEqual(self.sources, ["same-source"])
        self.assertEqual([len(existing) for existing in self.plans], [0, 2])
        self.assertEqual([call[2].name for call in self.mux_calls],
                         ["first_1.mp4", "first_2.mp4", "next_1.mp4",
                          "next_2.mp4", "next_3.mp4"])
        self.synth.assert_called_once()
        self.assertEqual(self.synth.call_args.kwargs["voice"], "en-GB-RyanNeural")
        self.assertEqual(len(sections_rendered), 5)
        for sections in sections_rendered:
            self.assertIn(len(sections), (4, 5))
            lengths = [end - start for start, end in sections]
            self.assertGreaterEqual(sum(lengths), 20 - 1e-8)
            self.assertLessEqual(sum(lengths), 30 + 1e-8)
            for (start, end), length in zip(sections, lengths):
                self.assertGreaterEqual(start, 0)
                self.assertLessEqual(end, 1000)
                self.assertGreaterEqual(length, 5 - 1e-8)
                self.assertLessEqual(length, 8 + 1e-8)

    def test_requested_link_planner_does_not_change_image_video_controls(self):
        from narration_planner import install_planner

        install_planner(self.generator)
        images = self.root / "images"
        images.mkdir()
        original_prepare = self.generator._prepare_image_dir
        original_pan_main = self.generator._build_pan_main
        prepared_options, rendered_pan = [], []

        def capture_prepare(folder, cache, left, right, seconds, log):
            prepared_options.append((left, right, seconds))
            return original_prepare(folder, cache, left, right, seconds, log)

        def capture_pan(images, directions, seconds, ffmpeg, temporary):
            rendered_pan.append((list(images), list(directions), seconds))
            return original_pan_main(images, directions, seconds, ffmpeg, temporary)

        self.generator._prepare_image_dir = capture_prepare
        self.generator._build_pan_main = capture_pan
        with patch.object(self.generator, "plan_sections",
                          side_effect=AssertionError("Image mode used link planner")):
            stats = self.presenter.generate_all(
                rows=[self.row("images_only", "Image narration.", 2,
                               image_dir=str(images), narration_voice="en-US-GuyNeural")],
                output_root=str(self.output), on_log=self.logs.append,
                pan_direction="rtl", pan_offset_left=0.12, pan_offset_right=0.23,
                pan_seconds=7.25,
            )

        self.assertEqual(stats, dict(rows=1, videos=2, errors=0))
        self.assertEqual(prepared_options, [(0.12, 0.23, 7.25)])
        self.assertEqual(len(rendered_pan), 2)
        for image_list, directions, seconds in rendered_pan:
            self.assertEqual(len(image_list), 3)
            self.assertEqual(directions, ["rtl"] * 3)
            self.assertEqual(seconds, 7.25)
        self.assertEqual(self.sources, [])
        self.assertEqual(self.plans, [])
        self.assertEqual(self.synth.call_args.kwargs["voice"], "en-US-GuyNeural")

    def test_short_link_source_reports_original_row_error_then_continues(self):
        from narration_planner import install_planner

        def source(url, cache, ffmpeg, on_log, max_h):
            self.sources.append(url)
            path = Path(cache) / "source.mp4"
            path.write_bytes(b"source")
            return str(path), 4.999 if url == "too-short-source" else 1000.0

        self.generator._obtain_source = source
        install_planner(self.generator)
        short = self.row("too_short", "Must not render.", 2)
        short["youtube_url"] = "too-short-source"
        valid = self.row("valid", "Render this row.", 1,
                         narration_voice="en-US-GuyNeural")
        valid["youtube_url"] = "valid-source"
        stats = self.generate([short, valid])

        # The original downloader counts one failed source row, and advances
        # progress over all requested outputs of that row before continuing.
        self.assertEqual(stats, dict(rows=2, videos=1, errors=1))
        self.assertEqual(self.sources, ["too-short-source", "valid-source"])
        self.assertEqual(self.progress, [(2, 3), (3, 3)])
        self.assertEqual([call[2].name for call in self.mux_calls], ["valid.mp4"])
        self.assertEqual([title for title, path in self.renders], ["valid"])
        self.assertFalse(list((self.output / "same folder").glob("too_short*.mp4")))
        self.synth.assert_called_once()
        self.assertEqual(self.synth.call_args.kwargs["voice"], "en-US-GuyNeural")
        self.assertTrue(any("Nguồn lỗi" in message and "5" in message
                            for message in self.logs), self.logs)


if __name__ == "__main__":
    unittest.main()
