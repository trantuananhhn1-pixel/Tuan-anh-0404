"""R4 link-video cut planning; image rendering and narration stay unchanged."""
from __future__ import annotations

import functools
import math

TOTAL_MIN = 20.0
TOTAL_MAX = 30.0
SECTION_MIN = 5.0
SECTION_MAX = 8.0
SECTION_COUNTS = (4, 5)


def _source_milliseconds(duration):
    try:
        value = float(duration)
    except (TypeError, ValueError):
        raise ValueError("Không đọc được thời lượng video nguồn hợp lệ.") from None
    if not math.isfinite(value) or value <= 0:
        raise ValueError("Không đọc được thời lượng video nguồn hợp lệ.")
    if value < SECTION_MIN:
        raise ValueError(
            "Video nguồn ngắn hơn 5 giây; không thể cắt mỗi đoạn 5–8 giây. "
            "Vui lòng dùng video nguồn dài ít nhất 5 giây."
        )
    return math.floor(value * 1000)


def plan_sections(source_duration, random_source):
    """Return 4/5 bounded cuts with a total of 20–30 seconds, in whole ms."""
    source_ms = _source_milliseconds(source_duration)
    minimum = int(SECTION_MIN * 1000)
    maximum = min(int(SECTION_MAX * 1000), source_ms)
    count = random_source.choice(SECTION_COUNTS)
    lower_total = max(int(TOTAL_MIN * 1000), count * minimum)
    upper_total = min(int(TOTAL_MAX * 1000), count * maximum)
    remaining = random_source.randint(lower_total, upper_total)
    sections = []
    for index in range(count):
        after = count - index - 1
        # Leave enough (and not too much) time for every remaining segment.
        low = max(minimum, remaining - after * maximum)
        high = min(maximum, remaining - after * minimum)
        length = random_source.randint(low, high)
        start = random_source.randint(0, source_ms - length)
        sections.append((start / 1000, (start + length) / 1000))
        remaining -= length
    return sections


def install_planner(generator=None):
    if generator is None:
        from core import video_generator as generator
    if getattr(generator, "_link_clip_planner_installed", False):
        return
    original_plan = generator.plan_sections

    @functools.wraps(original_plan)
    def selected_sections(source_duration):
        return plan_sections(source_duration, generator.random)

    original_source = getattr(generator, "_obtain_source", None)
    if original_source is not None:
        @functools.wraps(original_source)
        def checked_source(*args, **kwargs):
            result = original_source(*args, **kwargs)
            # This call is inside the original per-row source-error handler;
            # reject an impossible short source without aborting later rows.
            _source_milliseconds(result[1])
            log = kwargs.get("on_log") or (args[3] if len(args) > 3 else None)
            if log:
                log("✂️ Cắt video R4: 20–30 giây, 4–5 đoạn, mỗi đoạn 5–8 giây.")
            return result

        generator._obtain_source = checked_source

    generator.TOTAL_MIN = TOTAL_MIN
    generator.TOTAL_MAX = TOTAL_MAX
    generator.SECTION_MIN = SECTION_MIN
    generator.SECTION_MAX = SECTION_MAX
    generator.plan_sections = selected_sections
    generator._link_clip_planner_installed = True
