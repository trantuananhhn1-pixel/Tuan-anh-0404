"""Optional per-row narration adapters for the original seven-column UI.

This module has no import-time application effects.  install_ui() adds only the
optional eighth field and delegates all existing options to the original code.
"""

from functools import wraps
from importlib import import_module
from types import FunctionType
import re
import unicodedata


NARRATION_KEY = "narration"
NARRATION_HEADER = "Lời thuyết minh"
NARRATION_STATUS = (
    "🔊 Bản Thuyết minh R2 đã sẵn sàng — giọng nữ tiếng Anh Jenny. "
    "Nhập lời đọc ở cột “Lời thuyết minh”; để trống để không thêm giọng đọc."
)
NARRATION_ALIASES = frozenset(
    (
        "narration",
        "lời thuyết minh",
        "loi thuyet minh",
        "nội dung thuyết minh",
        "noi dung thuyet minh",
        "lời đọc",
        "loi doc",
        "voiceover",
    )
)


def _normalize_narration_header(value):
    """Recognize equivalent spreadsheet headers without changing their text."""
    text = unicodedata.normalize("NFKC", str(value))
    text = "".join(character for character in text
                   if unicodedata.category(character) != "Cf")
    return " ".join(text.split()).casefold()


def _narration_column_positions(frame):
    if frame is None:
        return []
    headers = [_normalize_narration_header(header) for header in frame.columns]
    base_headers = set(headers) & NARRATION_ALIASES
    positions = []
    for position, header in enumerate(headers):
        if header in NARRATION_ALIASES:
            positions.append(position)
            continue
        # pandas labels exact duplicate Excel headers as "header.1", ".2", ...
        # Recognize only suffixes whose original narration header is also here.
        match = re.fullmatch(r"(.+)\.([1-9][0-9]*)", header)
        if match and _normalize_narration_header(match.group(1)) in base_headers:
            positions.append(position)
    return positions


def _cell_text(value):
    """Match the original normalizer's handling of blank spreadsheet cells."""
    text = str(value).strip()
    return "" if text in ("nan", "None") else text


def _coalesce_narration(frame, row_index, column_positions):
    nonempty = []
    for position in column_positions:
        value = _cell_text(frame.iloc[row_index, position])
        if value and value not in nonempty:
            nonempty.append(value)
    if len(nonempty) > 1:
        raise ValueError(
            f"Dòng dữ liệu {row_index + 1} có nhiều cột lời thuyết minh "
            "với nội dung khác nhau. Vui lòng chỉ giữ một nội dung lời đọc."
        )
    return nonempty[0] if nonempty else ""


def _retained_positions(frame, original_columns, original_aliases):
    """Mirror only the original source-row filter, without changing its data."""
    normalized_headers = [str(header).strip().lower() for header in frame.columns]
    source_positions = []
    for key in ("folder", "youtube_url", "image_dir"):
        position = next(
            (i for i, header in enumerate(normalized_headers)
             if header in original_aliases[key]),
            None,
        )
        fallback = original_columns.index(key)
        if position is None and fallback < len(normalized_headers):
            position = fallback
        if position is not None:
            source_positions.append(position)
    return [
        row_index
        for row_index, row in enumerate(frame.itertuples(index=False, name=None))
        if any(_cell_text(row[position]) for position in source_positions)
    ]


def _make_normalizer(original, original_columns, original_aliases):
    @wraps(original)
    def normalize_with_narration(frame):
        # An unnamed arbitrary eighth column must keep its original meaning;
        # narration is read only from an explicitly recognized header.
        column_positions = _narration_column_positions(frame)
        result = original(frame)
        if not column_positions or result.empty:
            result[NARRATION_KEY] = ""
            return result
        retained = _retained_positions(frame, original_columns, original_aliases)
        if len(retained) != len(result):
            raise ValueError("Không thể ghép lời thuyết minh đúng với từng dòng video.")
        result[NARRATION_KEY] = [
            _coalesce_narration(frame, row_index, column_positions)
            for row_index in retained
        ]
        return result

    return normalize_with_narration


class _SheetSnapshot:
    def __init__(self, original, frame):
        self._original = original
        self._frame = frame

    def to_df(self):
        return self._frame

    def __getattr__(self, name):
        return getattr(self._original, name)


class _ViewSnapshot:
    """Give the old config getter its original seven columns, without mutation."""
    def __init__(self, original, frame):
        self._original = original
        self.gen_sheet = _SheetSnapshot(original.gen_sheet, frame)

    def __getattr__(self, name):
        return getattr(self._original, name)


class _RawSheetSnapshot:
    def __init__(self, original, rows):
        self._original = original
        self._rows = rows

    def get_sheet_data(self):
        return self._rows

    def __getattr__(self, name):
        return getattr(self._original, name)


class _TableSnapshot:
    def __init__(self, original, rows):
        self._original = original
        self.sheet = _RawSheetSnapshot(original.sheet, rows)

    def __getattr__(self, name):
        return getattr(self._original, name)


def _make_table_getter(original, original_columns):
    # The original getter assembles exactly seven fields.  Clone its globals so
    # extending the live table metadata cannot change those original semantics.
    original_globals = dict(original.__globals__, COLS=list(original_columns))
    seven_column_getter = FunctionType(
        original.__code__, original_globals, original.__name__,
        original.__defaults__, original.__closure__,
    )

    @wraps(original)
    def to_df_with_narration(table):
        rows = [list(row) for row in table.sheet.get_sheet_data()]
        result = seven_column_getter(_TableSnapshot(table, rows))
        narrations = []
        for raw_row in rows:
            row = raw_row + [""] * (len(original_columns) + 1)
            folder = str(row[0]).strip()
            url = str(row[1]).strip()
            image_dir = str(row[6]).strip().strip('"')
            if folder or url or image_dir:
                narrations.append(_cell_text(row[len(original_columns)]))
        if len(result) != len(narrations):
            raise ValueError("Không thể ghép lời thuyết minh đúng với từng dòng video.")
        result[NARRATION_KEY] = narrations
        return result

    return to_df_with_narration


def _make_config_getter(original, original_columns):
    @wraps(original)
    def get_run_config_with_narration(view):
        frame = view.gen_sheet.to_df()
        original_frame = frame.reindex(columns=original_columns, fill_value="")
        config = original(_ViewSnapshot(view, original_frame))
        narrations = (
            [_cell_text(value) for value in frame[NARRATION_KEY].tolist()]
            if NARRATION_KEY in frame.columns
            else [""] * len(frame)
        )
        if len(config["rows"]) != len(narrations):
            raise ValueError("Không thể ghép lời thuyết minh đúng với từng dòng video.")
        for row, narration in zip(config["rows"], narrations):
            row[NARRATION_KEY] = narration
        return config

    return get_run_config_with_narration


def _make_presenter_setter(original):
    @wraps(original)
    def set_presenter_with_status(view, *args, **kwargs):
        result = original(view, *args, **kwargs)
        if not getattr(view, "_narration_status_logged", False):
            view.append_log(NARRATION_STATUS)
            view._narration_status_logged = True
        return result

    return set_presenter_with_status


def install_ui():
    """Install the optional field once; existing UI defaults remain delegated."""
    sheet_source = import_module("core.sheet_source")
    table_module = import_module("views.components.gen_sheet")
    window_module = import_module("views.video_gen_window")
    window_class = window_module.VideoGenWindow
    if getattr(window_class, "_narration_ui_installed", False):
        return

    original_columns = tuple(table_module.COLS)
    if NARRATION_KEY in original_columns:
        raise RuntimeError("Bảng video đã có cột narration chưa được nhận diện.")
    source_columns = tuple(sheet_source.GEN_COLS)
    if original_columns != source_columns:
        raise RuntimeError("Cấu trúc bảng video không khớp phiên bản tool gốc.")

    normalizer = _make_normalizer(
        sheet_source._normalize_gen_df,
        source_columns,
        sheet_source._GEN_ALIASES,
    )
    config_getter = _make_config_getter(
        window_class.get_run_config, original_columns
    )
    table_getter = _make_table_getter(
        table_module.GenSheet.to_df, original_columns
    )
    presenter_setter = _make_presenter_setter(window_class.set_presenter)
    table_module.COLS = list(original_columns) + [NARRATION_KEY]
    table_module.HEADERS_VI = list(table_module.HEADERS_VI) + [NARRATION_HEADER]
    sheet_source._normalize_gen_df = normalizer
    sheet_source.GEN_TEMPLATE_HEADERS = list(sheet_source.GEN_TEMPLATE_HEADERS) + [
        NARRATION_HEADER
    ]
    sheet_source.GEN_TEMPLATE_ROWS = [
        list(row) + [""] for row in sheet_source.GEN_TEMPLATE_ROWS
    ]
    window_class.get_run_config = config_getter
    window_class.set_presenter = presenter_setter
    table_module.GenSheet.to_df = table_getter
    window_class._narration_ui_installed = True
