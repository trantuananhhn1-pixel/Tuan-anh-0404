"""Optional per-row narration; the original pipeline handles all blank rows."""
from __future__ import annotations

import functools
import inspect
import math
import os
from pathlib import Path
import re
import subprocess
import tempfile
import threading
import time

_local = threading.local()


def _creation_flags():
    return getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0


def _run_command(command, should_stop=None, timeout=120):
    """Keep stderr off a pipe so a child cannot deadlock during cancellation."""
    with tempfile.TemporaryFile() as errors:
        process = subprocess.Popen(
            command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
            stderr=errors, creationflags=_creation_flags(),
        )
        deadline = time.monotonic() + timeout
        try:
            while True:
                if should_stop and should_stop():
                    raise RuntimeError("Đã dừng tạo giọng thuyết minh.")
                if time.monotonic() > deadline:
                    raise RuntimeError("Quá thời gian xử lý âm thanh thuyết minh.")
                try:
                    returncode = process.wait(timeout=0.2)
                    break
                except subprocess.TimeoutExpired:
                    continue
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
        errors.seek(0)
        diagnostic = errors.read().decode("utf-8", "replace")
        if returncode:
            raise RuntimeError("Không ghép được giọng đọc: " + diagnostic[-2000:])
        return diagnostic


def probe_duration(ffmpeg, path):
    result = subprocess.run(
        [str(ffmpeg), "-hide_banner", "-i", str(path)],
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE, creationflags=_creation_flags(), timeout=30,
    )
    diagnostic = result.stderr.decode("utf-8", "replace")
    match = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", diagnostic)
    if not match:
        raise RuntimeError("Không đọc được thời lượng tệp: " + Path(path).name)
    hours, minutes, seconds = map(float, match.groups())
    duration = hours * 3600 + minutes * 60 + seconds
    if not math.isfinite(duration) or duration <= 0:
        raise RuntimeError("Thời lượng âm thanh/video không hợp lệ.")
    return duration


def _tempo_filters(factor):
    factors = []
    while factor > 2:
        factors.append("atempo=2")
        factor /= 2
    if factor > 1.000001:
        factors.append(f"atempo={factor:.9f}")
    return factors


def verify_audible_audio(video, ffmpeg, should_stop=None):
    """Decode the audio before declaring a narrated output successful."""
    diagnostic = _run_command([
        str(ffmpeg), "-hide_banner", "-nostdin", "-i", str(video),
        "-map", "0:a:0", "-vn", "-sn", "-dn", "-af", "volumedetect",
        "-f", "null", "-",
    ], should_stop, max(120, probe_duration(ffmpeg, video) * 3))
    # FFmpeg can log an initial zero-sample filter instance before its final
    # initialized decoder; use the last reported result rather than that probe.
    samples = re.findall(r"n_samples:\s*(\d+)", diagnostic)
    peaks = re.findall(r"max_volume:\s*(-?\d+(?:\.\d+)?)\s*dB", diagnostic)
    if not samples or int(samples[-1]) == 0 or not peaks:
        raise RuntimeError("Không xác nhận được âm thanh trong video thuyết minh.")
    if float(peaks[-1]) <= -80:
        raise RuntimeError("Âm thanh thuyết minh bị im lặng; không xuất video như đã thành công.")


def mux_narration(video, audio, output, ffmpeg, log=None, should_stop=None):
    """Copy video packets unchanged and fit the entire narration to its duration."""
    duration = probe_duration(ffmpeg, video)
    audio_duration = probe_duration(ffmpeg, audio)
    filters = []
    if audio_duration > duration:
        factor = (audio_duration + 0.1) / duration
        filters.extend(_tempo_filters(factor))
        if log:
            log(f"🔊 Lời đọc dài hơn video; tăng tốc {factor:.2f} lần để giữ nguyên thời lượng video.")
    filters.append("apad")
    target = Path(output)
    handle = tempfile.NamedTemporaryFile(
        prefix=".narration_", suffix=".mp4", dir=str(target.parent), delete=False,
    )
    temporary = Path(handle.name)
    handle.close()
    try:
        _run_command([
            str(ffmpeg), "-hide_banner", "-loglevel", "error", "-nostdin", "-y",
            "-i", str(video), "-i", str(audio),
            "-map", "0:v:0", "-map", "1:a:0", "-map_metadata", "0",
            "-c:v", "copy", "-af", ",".join(filters),
            "-c:a", "aac", "-b:a", "192k", "-t", f"{duration:.6f}",
            "-movflags", "+faststart", str(temporary),
        ], should_stop, max(120, duration * 5))
        if not temporary.is_file() or temporary.stat().st_size == 0:
            raise RuntimeError("Không tạo được video có giọng thuyết minh.")
        verify_audible_audio(temporary, ffmpeg, should_stop)
        if should_stop and should_stop():
            raise RuntimeError("Đã dừng tạo giọng thuyết minh.")
        os.replace(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)


class _NarrationRows(list):
    def __init__(self, rows, state):
        super().__init__(rows)
        self.state = state

    def __iter__(self):
        previous = self.state.get("row")
        try:
            for row in super().__iter__():
                self.state["row"] = row
                yield row
        finally:
            self.state["row"] = previous


def install_audio(generator=None, presenter=None, synthesizer=None):
    if generator is None:
        from core import video_generator as generator
    if presenter is None:
        from presenters import video_gen_presenter as presenter
    if synthesizer is None:
        from narration_tts import synthesize as synthesizer
    if getattr(generator, "_narration_installed", False):
        return
    original_generate = generator.generate_all
    original_finish = generator._finish_video
    generate_signature = inspect.signature(original_generate)
    finish_signature = inspect.signature(original_finish)

    @functools.wraps(original_generate)
    def generate(*args, **kwargs):
        bound = generate_signature.bind(*args, **kwargs)
        rows = bound.arguments.get("rows", [])
        log = bound.arguments.get("on_log") or (lambda message: None)
        narrated_rows = sum(bool(str(row.get("narration") or "").strip()) for row in rows)
        log(f"🔊 Thuyết minh R2: {narrated_rows}/{len(rows)} dòng có lời đọc — giọng nữ tiếng Anh Jenny.")
        # Preserve original argument objects and behavior when narration is off.
        if not narrated_rows:
            log("🔊 Không có nội dung lời thuyết minh trong bảng của tool; lượt này giữ video không tiếng như bản gốc.")
            return original_generate(*args, **kwargs)
        previous = getattr(_local, "state", None)
        with tempfile.TemporaryDirectory(prefix="vgen_narration_") as work:
            state = {
                "row": None, "work": Path(work), "audio": {}, "failures": {},
                "log": log,
                "stop": bound.arguments.get("should_stop"),
            }
            _local.state = state
            bound.arguments["rows"] = _NarrationRows(rows, state)
            try:
                return original_generate(*bound.args, **bound.kwargs)
            finally:
                _local.state = previous

    @functools.wraps(original_finish)
    def finish(*args, **kwargs):
        state = getattr(_local, "state", None)
        row = (state.get("row") or {}) if state else {}
        text = str(row.get("narration") or "").strip()
        if not text:
            return original_finish(*args, **kwargs)
        if state["stop"] and state["stop"]():
            raise RuntimeError("Đã dừng tạo giọng thuyết minh.")
        if text in state["failures"]:
            raise RuntimeError(state["failures"][text])
        if text not in state["audio"]:
            state["log"]("🔊 Đang tạo giọng nữ tiếng Anh Jenny...")
            destination = state["work"] / f"speech_{len(state['audio'])}.mp3"
            try:
                synthesizer(text, destination, should_stop=state["stop"])
                if not destination.is_file() or not destination.stat().st_size:
                    raise RuntimeError("Dịch vụ không trả về âm thanh thuyết minh.")
            except Exception as error:
                state["failures"][text] = str(error)
                raise
            state["audio"][text] = destination
        bound = finish_signature.bind(*args, **kwargs)
        final_output = bound.arguments["out_path"]
        # The original renderer writes to staging, so failed speech never leaves
        # an apparently successful silent output or replaces an existing file.
        with tempfile.TemporaryDirectory(prefix="render_", dir=state["work"]) as staging:
            rendered = Path(staging) / "visual.mp4"
            bound.arguments["out_path"] = str(rendered)
            result = original_finish(*bound.args, **bound.kwargs)
            mux_narration(
                rendered, state["audio"][text], final_output,
                bound.arguments["ffmpeg_exe"], state["log"], state["stop"],
            )
        state["log"]("🔊 Đã ghép lời thuyết minh vào video.")
        return result

    generator._finish_video = finish
    generator.generate_all = generate
    # Presenter may have imported the function before this hook ran.
    if getattr(presenter, "generate_all", None) is original_generate:
        presenter.generate_all = generate
    generator._narration_installed = True
