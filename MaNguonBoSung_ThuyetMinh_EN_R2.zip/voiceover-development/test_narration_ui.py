"""Regression checks against the original tool's reviewed pure methods."""

import importlib.util
import marshal
from pathlib import Path
import sys
import tempfile
import types
import unicodedata
import unittest
from unittest.mock import Mock, patch

import pandas as pd
from pandas.testing import assert_frame_equal

import narration_ui as subject


BYTECODE = Path(__file__).resolve().parents[1] / "extracted" / "app-bytecode"


def load_code(relative):
    return marshal.loads((BYTECODE / relative).read_bytes()[16:])


def child_code(parent, name):
    return next(c for c in parent.co_consts
                if isinstance(c, types.CodeType) and c.co_name == name)


def source_module():
    # Reviewed top level: imports re/pandas, constant tables, function definitions.
    # File/URL readers remain uncalled unless a test explicitly invokes a mock.
    module = types.ModuleType("core.sheet_source")
    exec(load_code("core/sheet_source.pyc"), module.__dict__)
    return module


def original_window_methods():
    module_code = load_code("views/video_gen_window.pyc")
    class_code = child_code(module_code, "VideoGenWindow")
    namespace = {
        "pd": pd,
        "QUALITY_OPTIONS": {"HD": 720, "Full HD": 1080},
        "PAN_OPTIONS": {"Left": "ltr", "Right": "rtl"},
    }
    namespace["_parse_float"] = types.FunctionType(
        child_code(module_code, "_parse_float"), namespace
    )
    methods = {}
    for name in ("get_run_config", "get_ui_state", "apply_ui_state", "set_presenter"):
        methods[name] = types.FunctionType(child_code(class_code, name), namespace)
    return methods


class Value:
    def __init__(self, value):
        self.value = value

    def get(self):
        return self.value

    def set(self, value):
        self.value = value

    def select(self):
        self.value = True

    def deselect(self):
        self.value = False


class FakeTable:
    def __init__(self, frame):
        self.frame = frame

    def to_df(self):
        return self.frame.copy()

    def load_df(self, frame):
        self.frame = frame.copy()


def fake_view(frame):
    view = types.SimpleNamespace(
        gen_sheet=FakeTable(frame),
        txt_output=Value(" /output "),
        txt_gsheet=Value("https://docs.google.com/sheets/d/example/edit"),
        opt_quality=Value("HD"),
        chk_random_style=Value(True),
        opt_pan_dir=Value("Right"),
        txt_pan_left=Value("12,5"),
        txt_pan_right=Value("7"),
        txt_pan_seconds=Value("8.5"),
    )
    view._set_entry = lambda entry, value: entry.set(str(value))
    return view


class NarrationNormalizerTests(unittest.TestCase):
    def setUp(self):
        self.source = source_module()
        self.original = self.source._normalize_gen_df
        self.normalize = subject._make_normalizer(
            self.original,
            tuple(self.source.GEN_COLS),
            self.source._GEN_ALIASES,
        )

    def test_old_seven_column_data_is_unchanged(self):
        data = pd.DataFrame([
            ["f", "https://youtube/a", "Large", "Small", "name", 2, ""],
            [None, None, None, None, None, None, None],
            ["images", "", "Images", "", "", "bad count", "C:/images"],
        ], columns=self.source.GEN_COLS, index=[20, 35, 70])
        old = self.original(data)
        result = self.normalize(data)
        assert_frame_equal(result.drop(columns="narration"), old)
        self.assertEqual(result.narration.tolist(), ["", ""])

    def test_optional_text_stays_aligned_after_blank_rows_are_filtered(self):
        data = pd.DataFrame({
            "Tên folder": ["first", None, "third", "None", "nan"],
            "Link Video": ["", None, "https://youtu.be/x", None, None],
            "Tiêu đề to": ["A", "B", "C", "D", "E"],
            "Tiêu đề nhỏ": ["", "", "", "", ""],
            "Tên file": ["a", "b", "c", "d", "e"],
            "Số lượng": [1, 1, 2, 1, 1],
            "Thư mục ảnh": ["images", None, "", None, None],
            " LỜI THUYẾT MINH ": [" Đầu tiên ", "discard", "Thứ ba", "discard", "discard"],
        }, index=[9, 1, 80, 5, 99])
        result = self.normalize(data)
        assert_frame_equal(result.drop(columns="narration"), self.original(data))
        self.assertEqual(result.narration.tolist(), ["Đầu tiên", "Thứ ba"])

    def test_reordered_headers_and_blank_narration(self):
        data = pd.DataFrame({
            "voiceover": [float("nan"), None, "Xin chào"],
            "Tên folder": ["a", "b", "c"],
            "Link Video": ["https://x", "https://y", "https://z"],
            "Thư mục ảnh": ["", "", ""],
        })
        result = self.normalize(data)
        assert_frame_equal(result.drop(columns="narration"), self.original(data))
        self.assertEqual(result.narration.tolist(), ["", "", "Xin chào"])

    def test_arbitrary_eighth_column_does_not_become_narration(self):
        data = pd.DataFrame([
            ["f", "url", "big", "small", "file", 1, "", "old arbitrary data"]
        ], columns=list(self.source.GEN_COLS) + ["Unrelated"])
        result = self.normalize(data)
        assert_frame_equal(result.drop(columns="narration"), self.original(data))
        self.assertEqual(result.narration.tolist(), [""])

    def test_none_and_empty_frames(self):
        for data in (None, pd.DataFrame(columns=self.source.GEN_COLS)):
            result = self.normalize(data)
            assert_frame_equal(result.drop(columns="narration"), self.original(data))
            self.assertEqual(result.narration.tolist(), [])

    def test_ninth_column_header_is_recognized(self):
        data = pd.DataFrame([
            ["folder", "url", "big", "small", "file", 1, "images", "unrelated", "Xin chào"]
        ], columns=list(self.source.GEN_COLS) + ["Khác", "Lời thuyết minh"])
        original_data = data.copy(deep=True)
        result = self.normalize(data)
        self.assertEqual(result.narration.tolist(), ["Xin chào"])
        assert_frame_equal(result.drop(columns="narration"), self.original(data))
        assert_frame_equal(data, original_data)

    def test_unicode_equivalent_narration_headers_are_recognized(self):
        headers = [
            unicodedata.normalize("NFD", "Lời thuyết minh"),
            "Lời\u00a0thuyết\u00a0minh",
            "\ufeffLời thuyết minh",
            "Lời\u200b thuyết minh",
            " LỜI\t THUYẾT\nMINH ",
            "ＶＯＩＣＥＯＶＥＲ",
        ]
        for header in headers:
            with self.subTest(header=repr(header)):
                data = pd.DataFrame([
                    ["folder", "url", "big", "small", "file", 1, "images", "unrelated", "Xin chào"]
                ], columns=list(self.source.GEN_COLS) + ["Khác", header])
                result = self.normalize(data)
                self.assertEqual(result.narration.tolist(), ["Xin chào"])
                assert_frame_equal(result.drop(columns="narration"), self.original(data))

    def test_duplicate_recognized_headers_fail_instead_of_choosing_one(self):
        for duplicate in ("narration", "\ufeffLời\u00a0thuyết minh"):
            with self.subTest(header=repr(duplicate)):
                data = pd.DataFrame([
                    ["folder", "url", "big", "small", "file", 1, "images", "First", "Second"]
                ], columns=list(self.source.GEN_COLS) + ["Lời thuyết minh", duplicate])
                with self.assertRaisesRegex(ValueError, "nhiều cột"):
                    self.normalize(data)

    def test_duplicate_narration_columns_coalesce_blank_or_identical_values(self):
        data = pd.DataFrame([
            ["a", "url", "big", "small", "a", 1, "images", "", "Only in I", None],
            ["b", "url", "big", "small", "b", 1, "images", "Same words", " Same words ", "Same words"],
            ["c", "url", "big", "small", "c", 1, "images", None, None, "Third column"],
        ], columns=list(self.source.GEN_COLS) + [
            "Lời thuyết minh", "Lời thuyết minh.1", "Lời thuyết minh.2"
        ])
        result = self.normalize(data)
        self.assertEqual(result.narration.tolist(), ["Only in I", "Same words", "Third column"])
        assert_frame_equal(result.drop(columns="narration"), self.original(data))

    def test_pandas_suffixed_narration_headers_need_matching_original_header(self):
        data = pd.DataFrame([
            ["a", "url", "big", "small", "a", 1, "images", "Do not guess"]
        ], columns=list(self.source.GEN_COLS) + ["Lời thuyết minh.1"])
        self.assertEqual(self.normalize(data).narration.tolist(), [""])
        data["narration"] = "Actual narration"
        self.assertEqual(self.normalize(data).narration.tolist(), ["Actual narration"])

    def test_pandas_duplicate_headers_with_trailing_whitespace_are_recognized(self):
        data = pd.DataFrame([
            ["a", "url", "big", "small", "a", 1, "images", "", "Read from duplicate"]
        ], columns=list(self.source.GEN_COLS) + ["Lời thuyết minh ", "Lời thuyết minh .1"])
        self.assertEqual(self.normalize(data).narration.tolist(), ["Read from duplicate"])

    def test_conflicting_pandas_duplicate_columns_raise_clear_row_error(self):
        data = pd.DataFrame([
            ["a", "url", "big", "small", "a", 1, "images", "First", "Different"]
        ], columns=list(self.source.GEN_COLS) + ["Lời thuyết minh", "Lời thuyết minh.1"])
        with self.assertRaisesRegex(ValueError, "Dòng dữ liệu 1.*khác nhau"):
            self.normalize(data)


class ConfigTests(unittest.TestCase):
    def setUp(self):
        self.source = source_module()
        self.columns = self.source.GEN_COLS
        self.methods = original_window_methods()
        self.original = self.methods["get_run_config"]
        self.patched = subject._make_config_getter(self.original, self.columns)

    def test_every_old_config_option_and_row_is_preserved(self):
        frame = pd.DataFrame([
            ["f", "https://example/a", "big", "small", "name", "2", ""],
            ["", "", "", "", "", "nonsense", ""],
            ["images", "", "", "", "im", "3.7", "/images"],
        ], columns=self.columns)
        view = fake_view(frame)
        expected = self.original(view)
        original_table = view.gen_sheet
        result = self.patched(view)
        self.assertIs(view.gen_sheet, original_table)
        for row in result["rows"]:
            self.assertEqual(row.pop("narration"), "")
        self.assertEqual(result, expected)

    def test_narration_attaches_to_each_row_and_original_df_is_unmodified(self):
        frame = pd.DataFrame([
            ["a", "url", "big", "small", "a", 1, "", "Xin chào"],
            ["b", "url", "big", "small", "b", 2, "", "Lời thứ hai"],
        ], columns=list(self.columns) + ["narration"])
        before = frame.copy(deep=True)
        result = self.patched(fake_view(frame))
        self.assertEqual([r["narration"] for r in result["rows"]], ["Xin chào", "Lời thứ hai"])
        assert_frame_equal(frame, before)
        self.assertEqual(result["rows"][1]["count"], 2)
        self.assertEqual(result["pan_offset_left"], .125)


class InstallationAndPersistenceTests(unittest.TestCase):
    def setUp(self):
        self.source = source_module()
        self.methods = original_window_methods()
        self.table = types.ModuleType("views.components.gen_sheet")
        self.table.COLS = list(self.source.GEN_COLS)
        self.table.HEADERS_VI = list(self.source.GEN_TEMPLATE_HEADERS)
        self.table.pd = pd
        table_class_code = child_code(load_code("views/components/gen_sheet.pyc"), "GenSheet")
        self.table.GenSheet = type("PureOriginalTable", (), {
            name: types.FunctionType(child_code(table_class_code, name), self.table.__dict__)
            for name in ("load_df", "to_df", "add_row")
        })
        self.window_module = types.ModuleType("views.video_gen_window")
        self.window_module.VideoGenWindow = type("VideoGenWindow", (), self.methods)
        modules = {
            "core.sheet_source": self.source,
            "views.components.gen_sheet": self.table,
            "views.video_gen_window": self.window_module,
        }
        # The original restore method uses a regular dotted import.
        for name in ("core", "views", "views.components"):
            module = types.ModuleType(name)
            module.__path__ = []
            modules[name] = module
        modules["core"].sheet_source = self.source
        modules["views"].components = modules["views.components"]
        modules["views.components"].gen_sheet = self.table
        modules["views"].video_gen_window = self.window_module
        self.patch = patch.dict(sys.modules, modules)
        self.patch.start()
        self.addCleanup(self.patch.stop)

    def test_install_is_idempotent_and_template_preserves_every_old_cell(self):
        old_headers = list(self.source.GEN_TEMPLATE_HEADERS)
        old_rows = [list(row) for row in self.source.GEN_TEMPLATE_ROWS]
        subject.install_ui()
        subject.install_ui()
        self.assertEqual(self.table.COLS, list(self.source.GEN_COLS) + ["narration"])
        self.assertEqual(self.source.GEN_TEMPLATE_HEADERS, old_headers + ["Lời thuyết minh"])
        self.assertEqual(self.source.GEN_TEMPLATE_ROWS, [row + [""] for row in old_rows])
        self.assertEqual(len(self.table.HEADERS_VI), 8)

    def test_original_presenter_setter_adds_feature_status_once(self):
        subject.install_ui()
        subject.install_ui()
        view = fake_view(pd.DataFrame(columns=self.table.COLS))
        view.append_log = Mock()
        presenter = object()
        result = self.window_module.VideoGenWindow.set_presenter(view, presenter)
        self.assertIsNone(result)
        self.assertIs(view.presenter, presenter)
        view.append_log.assert_called_once_with(subject.NARRATION_STATUS)
        replacement = object()
        self.window_module.VideoGenWindow.set_presenter(view, replacement)
        self.assertIs(view.presenter, replacement)
        view.append_log.assert_called_once()

    def test_presenter_status_preserves_original_return_and_does_not_mask_errors(self):
        sentinel = object()
        original = Mock(return_value=sentinel)
        setter = subject._make_presenter_setter(original)
        view = types.SimpleNamespace(append_log=Mock())
        presenter = object()
        self.assertIs(setter(view, presenter), sentinel)
        original.assert_called_once_with(view, presenter)
        view = types.SimpleNamespace(append_log=Mock(side_effect=RuntimeError("log failed")))
        with self.assertRaisesRegex(RuntimeError, "log failed"):
            setter(view, presenter)

    @unittest.skipUnless(importlib.util.find_spec("openpyxl"), "openpyxl unavailable")
    def test_new_excel_template_and_round_trip(self):
        subject.install_ui()
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "narration.xlsx"
            self.source.write_gen_template(str(target))
            raw = pd.read_excel(target)
            self.assertEqual(raw.columns[-1], "Lời thuyết minh")
            raw["Lời thuyết minh"] = raw["Lời thuyết minh"].astype(object)
            raw.loc[0, "Lời thuyết minh"] = "Đây là lời đọc riêng của video đầu tiên."
            raw.to_excel(target, index=False)
            loaded = self.source.read_gen_excel(str(target))
            self.assertEqual(loaded.narration.iloc[0], "Đây là lời đọc riêng của video đầu tiên.")
            self.assertEqual(loaded.narration.iloc[1], "")

    @unittest.skipUnless(importlib.util.find_spec("openpyxl"), "openpyxl unavailable")
    def test_excel_blank_original_h_and_filled_duplicate_i_round_trip(self):
        subject.install_ui()
        english_narration = (
            "Discover Busch Gardens Tampa Bay in Florida, where thrilling roller coasters, "
            "incredible wildlife, and exciting family attractions create unforgettable adventures."
        )
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "duplicate-narration.xlsx"
            original = pd.DataFrame([
                ["a", "url", "big", "small", "a", 1, "images", "", english_narration],
                ["b", "url", "big", "small", "b", 1, "images", "Same", "Same"],
            ], columns=list(self.source.GEN_TEMPLATE_HEADERS) + ["Lời thuyết minh"])
            original.to_excel(target, index=False)
            parsed = pd.read_excel(target)
            self.assertEqual(parsed.columns[7:].tolist(), ["Lời thuyết minh", "Lời thuyết minh.1"])
            loaded = self.source.read_gen_excel(str(target))
            self.assertEqual(loaded.narration.tolist(), [english_narration, "Same"])

    def test_google_sheet_reader_retains_new_field_without_extra_request(self):
        subject.install_ui()
        raw = pd.DataFrame({
            "Tên folder": ["a"], "Link Video": ["https://youtu.be/a"],
            "Lời thuyết minh": ["Lời đọc Google Sheet"],
        })
        with patch.object(self.source.pd, "read_csv", return_value=raw) as read:
            result = self.source.read_gen_sheet("https://docs.google.com/spreadsheets/d/abc/edit")
        self.assertEqual(result.narration.tolist(), ["Lời đọc Google Sheet"])
        read.assert_called_once()

    def test_original_state_methods_round_trip_new_and_old_saved_rows(self):
        subject.install_ui()
        frame = pd.DataFrame([
            ["a", "url", "Big", "Small", "a", "1", "", "Câu đọc"],
        ], columns=self.table.COLS)
        original = fake_view(frame)
        saved = self.methods["get_ui_state"](original)
        self.assertEqual(saved["rows"][0][-1], "Câu đọc")
        restored = fake_view(pd.DataFrame(columns=self.table.COLS))
        self.methods["apply_ui_state"](restored, saved)
        self.assertEqual(restored.gen_sheet.to_df().narration.tolist(), ["Câu đọc"])
        saved["rows"][0] = saved["rows"][0][:7]
        self.methods["apply_ui_state"](restored, saved)
        self.assertEqual(restored.gen_sheet.to_df().narration.tolist(), [""])

    def test_original_table_methods_handle_optional_eighth_column(self):
        class Sheet:
            def __init__(self):
                self.data = []
                self.current_headers = []

            def set_sheet_data(self, data, **kwargs):
                self.data = data

            def headers(self, headers):
                self.current_headers = headers

            def get_sheet_data(self):
                return self.data

            def insert_row(self, row):
                self.data.append(row)

            def get_total_rows(self):
                return len(self.data)

            def see(self, *args, **kwargs):
                pass

        table = self.table.GenSheet()
        table.sheet = Sheet()
        subject.install_ui()
        old_frame = pd.DataFrame([
            ["old", "url", "big", "small", "file", 2, ""]
        ], columns=self.source.GEN_COLS)
        table.load_df(old_frame)
        self.assertEqual(table.to_df().narration.tolist(), [""])
        self.assertEqual(table.sheet.current_headers[-1], "Lời thuyết minh")
        new_frame = old_frame.copy()
        new_frame["narration"] = "Nội dung riêng.\nCó nhiều dòng."
        table.load_df(new_frame)
        self.assertEqual(table.to_df().narration.tolist(), ["Nội dung riêng.\nCó nhiều dòng."])
        table.add_row()
        self.assertEqual(len(table.sheet.data[-1]), 8)
        # The original getter skips rows without folder, URL, or image source.
        self.assertEqual(table.to_df().narration.tolist(), ["Nội dung riêng.\nCó nhiều dòng."])
        table.sheet.data.insert(0, [""] * 7 + ["Narration without a source"])
        table.sheet.data.append(["another", "", "", "", "", "1", '"/images"', "Other video"])
        result = table.to_df()
        self.assertEqual(result.narration.tolist(), ["Nội dung riêng.\nCó nhiều dòng.", "Other video"])
        self.assertEqual(result.image_dir.tolist(), ["", "/images"])


if __name__ == "__main__":
    unittest.main()
