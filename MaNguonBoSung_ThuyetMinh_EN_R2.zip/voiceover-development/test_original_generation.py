"""Exercise narration hooks with selected, reviewed original function bytecode.

The original module body is never executed. Network, image preparation and video
rendering are replaced; original scheduling, naming, caching and stats run here.
"""
from pathlib import Path
import builtins
import dis
import marshal
import os
import random
import re
import shutil
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

import narration_audio as audio
import narration_tts as tts
import narration_ui as ui
import pandas as pd


BYTECODE = Path(__file__).resolve().parents[1] / "extracted/app-bytecode"


def code_from(module):
    return marshal.loads((BYTECODE / (module + ".pyc")).read_bytes()[16:])


def function_code(container, name):
    return next(c for c in container.co_consts
                if isinstance(c, types.CodeType) and c.co_name == name)


class OriginalGenerationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.output = self.root / "output"
        self.logs, self.progress, self.renders, self.sources, self.plans = [], [], [], [], []
        self.module_code = code_from("core/video_generator")
        self.generator = types.SimpleNamespace(
            __builtins__=builtins.__dict__, os=os, re=re, shutil=shutil,
            tempfile=tempfile, random=random.Random(12345),
            TOTAL_MIN=15.0, TOTAL_MAX=30.0, SECTION_MIN=6.0, SECTION_MAX=10.0,
            MAX_SIMILARITY=0.3, PAN_DIRECTIONS=("ltr", "rtl", "alternate"),
            MAX_PAN_OFFSET=0.45, DEFAULT_PAN_SECONDS=5.0, IMAGE_NAME_MAX=150,
            _FNAME_FORBIDDEN=set('\\/:*?"<>|'),
            _WINDOWS_FORBIDDEN=set('\\/:*?"<>|'),
            _ffmpeg_exe=lambda: "fake-ffmpeg",
            _arrow_default_path=lambda: None,
            _available_random_fonts=lambda: [], _detect_hw_encoder=lambda exe: None,
        )
        for name in [
            "plan_sections", "_dur", "overlap_ratio", "plan_many", "_local_path",
            "_resolve_dir", "_safe_filename", "_output_name", "_dedupe_name",
            "_image_output_base", "_image_orders", "_pan_directions",
            "build_one_video", "build_image_video", "generate_all",
        ]:
            setattr(self.generator, name, types.FunctionType(
                function_code(self.module_code, name), self.generator.__dict__, name,
            ))
        # These are the defaults visible in the reviewed original MAKE_FUNCTION.
        self.generator.generate_all.__defaults__ = (
            None, None, None, None, None, 1080, False, "ltr", 0.0, 0.0, 5.0,
        )
        self.generator._sanitize_folder = types.FunctionType(
            function_code(code_from("core/channel_downloader"), "_sanitize_folder"),
            self.generator.__dict__, "_sanitize_folder",
        )
        original_plan = self.generator.plan_many

        def plan(*args, **kwargs):
            self.plans.append(list(kwargs.get("existing", [])))
            return original_plan(*args, **kwargs)

        self.generator.plan_many = plan

        def source(url, cache, ffmpeg, log, max_h):
            self.sources.append(url)
            path = Path(cache) / "source.mp4"
            path.write_bytes(b"source")
            return str(path), 1000.0

        def main(src, sections, ffmpeg, temporary):
            path = Path(temporary) / "main.mp4"
            path.write_bytes(b"main")
            return str(path)

        def pan_main(images, directions, seconds, ffmpeg, temporary):
            return main(None, None, ffmpeg, temporary)

        def prepare_images(image_dir, cache, left, right, seconds, log):
            if not Path(image_dir).is_dir():
                raise RuntimeError("missing image source")
            return [str(Path(image_dir) / f"image_{i}.jpg") for i in range(3)]

        def finish(main, title_big, title_small, arrow, out_path, ffmpeg_exe, tmp,
                   style_random):
            self.renders.append((title_big, Path(out_path)))
            Path(out_path).write_bytes(b"silent-render")

        self.generator._obtain_source = source
        self.generator._build_main = main
        self.generator._build_pan_main = pan_main
        self.generator._prepare_image_dir = prepare_images
        self.generator._finish_video = finish
        self.presenter = types.SimpleNamespace(generate_all=self.generator.generate_all)
        self.synth = Mock(side_effect=lambda text, path, **kw: Path(path).write_bytes(b"MP3"))
        self.mux_calls = []

        def mux(video, speech, output, *args):
            self.mux_calls.append((Path(video), Path(speech), Path(output)))
            Path(output).write_bytes(b"narrated-render")

        self.mux_patch = patch.object(audio, "mux_narration", side_effect=mux)
        self.mux_patch.start()
        self.addCleanup(self.mux_patch.stop)
        audio.install_audio(self.generator, self.presenter, self.synth)

    def row(self, name, narration="", count=1, **kwargs):
        return dict(folder="same folder", youtube_url="same-source", title_big=name,
                    title_small="unchanged small title", filename=name, count=count,
                    narration=narration, **kwargs)

    def generate(self, rows):
        return self.presenter.generate_all(
            rows=rows, output_root=str(self.output), on_log=self.logs.append,
            on_progress=lambda done, total: self.progress.append((done, total)),
        )

    def test_original_video_loop_keeps_narration_aligned_and_source_cached(self):
        stats = self.generate([
            self.row("first", "Lời đọc thứ nhất", 2),
            self.row("blank", "", 1),
            self.row("last", "Lời đọc cuối", 2),
        ])
        self.assertEqual(stats, dict(rows=3, videos=5, errors=0))
        self.assertEqual(self.sources, ["same-source"])
        self.assertEqual([len(p) for p in self.plans], [0, 2, 3])
        self.assertEqual([c.args[0] for c in self.synth.call_args_list],
                         ["Lời đọc thứ nhất", "Lời đọc cuối"])
        self.assertEqual([c[2].name for c in self.mux_calls],
                         ["first_1.mp4", "first_2.mp4", "last_1.mp4", "last_2.mp4"])
        self.assertEqual((self.output / "same folder/blank.mp4").read_bytes(), b"silent-render")
        self.assertEqual(self.progress, [(i, 5) for i in range(1, 6)])
        self.assertIsNone(getattr(audio._local, "state", None))

    def test_original_image_loop_and_video_loop_share_row_context(self):
        images = self.root / "images"
        images.mkdir()
        rows = [self.row("pictures", "Đọc ảnh", 2, image_dir=str(images)),
                self.row("video", "Đọc video"), self.row("blank", "")]
        stats = self.generate(rows)
        self.assertEqual(stats, dict(rows=3, videos=4, errors=0))
        self.assertEqual([c.args[0] for c in self.synth.call_args_list], ["Đọc ảnh", "Đọc video"])
        self.assertEqual([c[2].name for c in self.mux_calls],
                         ["pictures_1.mp4", "pictures_2.mp4", "video.mp4"])
        self.assertEqual(self.sources, ["same-source"])
        self.assertEqual(self.progress[-1], (4, 4))

    def test_original_failure_stats_continue_and_do_not_leave_silent_narration(self):
        self.synth.side_effect = RuntimeError("speech service unavailable")
        stats = self.generate([self.row("failed", "Lời đọc", 2), self.row("plain", "")])
        self.assertEqual(stats, dict(rows=2, videos=1, errors=2))
        self.synth.assert_called_once()
        self.assertEqual(self.mux_calls, [])
        self.assertEqual([title for title, path in self.renders], ["plain"])
        self.assertEqual(sorted(p.name for p in (self.output / "same folder").glob("*.mp4")),
                         ["plain.mp4"])
        self.assertEqual(self.progress, [(1, 3), (2, 3), (3, 3)])

    def test_original_presenter_run_accepts_existing_config_without_ffmpeg_argument(self):
        presenter_code = code_from("presenters/video_gen_presenter")
        cls = function_code(presenter_code, "VideoGenPresenter")
        run = types.FunctionType(function_code(cls, "_run"), self.presenter.__dict__, "_run")
        self.presenter._stop_flag = False
        self.presenter._on_complete = Mock()
        self.presenter._log = self.logs.append
        self.presenter.view = types.SimpleNamespace(set_progress=Mock())
        self.presenter._ui = lambda callback, *args: callback(*args)
        run(self.presenter, dict(rows=[self.row("presented", "Xin chào")],
                                 output_root=str(self.output)))
        self.assertEqual(len(self.mux_calls), 1)
        self.assertEqual(self.mux_calls[0][2].name, "presented.mp4")
        self.presenter._on_complete.assert_called_once()
        self.assertTrue(any("1 video, 0 lỗi" in message for message in self.logs), self.logs)
        self.assertFalse(any(message.startswith("❌ Lỗi:") for message in self.logs), self.logs)

    def test_duplicate_excel_narration_reaches_original_ui_presenter_and_generation(self):
        sentence = (
            "Discover Busch Gardens Tampa Bay in Florida, where thrilling roller coasters, "
            "incredible wildlife, and exciting family attractions create unforgettable adventures."
        )
        source_code = code_from("core/sheet_source")
        instructions = list(dis.get_instructions(source_code))
        cols_end = next(i for i, item in enumerate(instructions)
                        if item.opname == "STORE_NAME" and item.argval == "GEN_COLS")
        aliases_end = next(i for i, item in enumerate(instructions)
                           if item.opname == "STORE_NAME" and item.argval == "_GEN_ALIASES")
        # Recover the original literal metadata without executing module setup.
        columns = next(value for value in source_code.co_consts
                       if isinstance(value, tuple) and value[:2] == ("folder", "youtube_url")
                       and len(value) == 7)
        alias_sets = [item.argval for item in instructions[cols_end:aliases_end]
                      if item.opname == "LOAD_CONST" and isinstance(item.argval, frozenset)]
        self.assertEqual(len(alias_sets), len(columns))
        aliases = dict(zip(columns, alias_sets))
        normalizer = types.FunctionType(
            function_code(source_code, "_normalize_gen_df"),
            dict(pd=pd, GEN_COLS=list(columns), _GEN_ALIASES=aliases),
        )
        normalize = ui._make_normalizer(normalizer, columns, aliases)
        spreadsheet = self.root / "duplicate-narration.xlsx"
        pd.DataFrame([
            ["same folder", "same-source", "Busch Gardens", "Original small title",
             "busch_gardens", 1, "", "", sentence],
        ], columns=[
            "Tên folder", "Link Video", "Tiêu đề to", "Tiêu đề nhỏ", "Tên file",
            "Số lượng video đầu ra", "Thư mục ảnh", "Lời thuyết minh", "Lời thuyết minh",
        ]).to_excel(spreadsheet, index=False)
        imported = pd.read_excel(spreadsheet)
        self.assertEqual(imported.columns[-2:].tolist(),
                         ["Lời thuyết minh", "Lời thuyết minh.1"])
        normalized = normalize(imported)

        raw_table = types.SimpleNamespace(
            set_sheet_data=lambda rows, **kwargs: setattr(raw_table, "rows", rows),
            get_sheet_data=lambda: raw_table.rows,
            headers=lambda headers: None,
        )
        table_namespace = dict(pd=pd, COLS=list(columns) + ["narration"],
                               HEADERS_VI=list(columns) + ["Lời thuyết minh"])
        table_code = function_code(code_from("views/components/gen_sheet"), "GenSheet")
        table = types.SimpleNamespace(sheet=raw_table)
        load_df = types.FunctionType(function_code(table_code, "load_df"), table_namespace)
        getter = types.FunctionType(function_code(table_code, "to_df"), table_namespace)
        getter = ui._make_table_getter(getter, columns)
        table.to_df = types.MethodType(getter, table)
        load_df(table, normalized)

        window_code = code_from("views/video_gen_window")
        window_class = function_code(window_code, "VideoGenWindow")
        window_namespace = dict(QUALITY_OPTIONS={"Full HD": 1080}, PAN_OPTIONS={"Left": "ltr"})
        window_namespace["_parse_float"] = types.FunctionType(
            function_code(window_code, "_parse_float"), window_namespace,
        )
        config_getter = types.FunctionType(
            function_code(window_class, "get_run_config"), window_namespace,
        )
        config_getter = ui._make_config_getter(config_getter, columns)

        def value(item):
            return types.SimpleNamespace(get=lambda: item)

        view = types.SimpleNamespace(
            gen_sheet=table, txt_output=value(str(self.output)),
            opt_quality=value("Full HD"), chk_random_style=value(False),
            opt_pan_dir=value("Left"), txt_pan_left=value("0"),
            txt_pan_right=value("0"), txt_pan_seconds=value("5"), set_progress=Mock(),
        )
        config = config_getter(view)
        self.assertEqual(config["rows"][0]["narration"], sentence)

        class SynchronousThread:
            def __init__(self, target, args, daemon):
                self.target, self.args = target, args

            def start(self):
                self.target(*self.args)

            def is_alive(self):
                return False

        results = []
        hooked_generate = self.presenter.generate_all

        def observe_generation(*args, **kwargs):
            stats = hooked_generate(*args, **kwargs)
            results.append(stats)
            return stats

        self.presenter.generate_all = observe_generation
        self.presenter.threading = types.SimpleNamespace(Thread=SynchronousThread)
        self.presenter._thread = None
        self.presenter._log = self.logs.append
        self.presenter.view = view
        self.presenter._ui = lambda callback, *args: callback(*args)
        presenter_class = function_code(code_from("presenters/video_gen_presenter"), "VideoGenPresenter")
        for name in ("_run", "start_generate"):
            method = types.FunctionType(function_code(presenter_class, name), self.presenter.__dict__)
            setattr(self.presenter, name, types.MethodType(method, self.presenter))
        completed = Mock()
        self.presenter.start_generate(config, completed)

        self.synth.assert_called_once()
        self.assertEqual(self.synth.call_args.args[0], sentence)
        self.assertEqual(tts.VOICE, "en-US-JennyNeural")
        self.assertEqual(results, [dict(rows=1, videos=1, errors=0)])
        self.assertEqual(len(self.mux_calls), 1)
        self.assertEqual(self.mux_calls[0][2].name, "busch_gardens.mp4")
        self.assertEqual(self.mux_calls[0][2].read_bytes(), b"narrated-render")
        self.assertTrue(any("Thuyết minh R2: 1/1" in message for message in self.logs), self.logs)
        completed.assert_called_once()


if __name__ == "__main__":
    unittest.main()
