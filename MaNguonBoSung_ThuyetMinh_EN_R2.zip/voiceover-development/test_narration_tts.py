"""Offline transport tests. No service, EXE, or embedded application is executed."""
import io
from pathlib import Path
import re
import ssl
import struct
import tempfile
import types
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit
from xml.etree import ElementTree
from xml.sax.saxutils import unescape

import narration_tts as tts


def audio_frame(payload, *, path="audio", content_type="audio/mpeg"):
    header = f"X-RequestId:123\r\nPath:{path}\r\n"
    if content_type is not None:
        header += f"Content-Type:{content_type}\r\n"
    raw_header = header.encode("ascii")
    return struct.pack("!H", len(raw_header)) + raw_header + payload


class FakeWebsocket:
    def __init__(self, messages):
        self.messages = iter(messages)
        self.sent = []
        self.closed = False

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.closed = True

    def send(self, message):
        self.sent.append(message)

    def recv(self, timeout):
        value = next(self.messages)
        if isinstance(value, BaseException):
            raise value
        return value


class NarrationTests(unittest.TestCase):
    def options(self):
        return patch.object(tts, "_connection_options", return_value=("wss://test", {}))

    def test_utf8_and_xml_sensitive_text_survive_bounded_chunks(self):
        text = "ế🙂&<>" * 4000
        chunks = list(tts._text_chunks(text))
        self.assertGreater(len(chunks), 1)
        self.assertTrue(all(len(chunk.encode("utf-8")) <= 4096 for chunk in chunks))
        self.assertEqual("".join(unescape(chunk) for chunk in chunks), text)
        for chunk in chunks:
            self.assertEqual(ElementTree.fromstring("<root>" + chunk + "</root>").text, unescape(chunk))

    def test_unusable_xml_controls_removed_but_vietnamese_preserved(self):
        self.assertEqual(tts._clean_text("  Chào\x00bạn\x0b!  "), "Chào bạn !")
        for text in ["", "\t\n", "\x00"]:
            with self.assertRaises(tts.NarrationError):
                tts._clean_text(text)

    def test_real_connection_configuration_preserves_tls_and_proxy(self):
        url, options = tts._connection_options(1760000123.0)
        parsed = urlsplit(url)
        query = parse_qs(parsed.query)
        self.assertEqual(parsed.scheme, "wss")
        self.assertEqual(parsed.hostname, tts.SERVICE_HOST)
        self.assertRegex(query["Sec-MS-GEC"][0], r"^[A-F0-9]{16}-[A-F0-9]{64}$")
        self.assertEqual(query["Sec-MS-GEC-Version"], ["2-143.0.3650.75"])
        self.assertTrue(options["ssl"].check_hostname)
        self.assertEqual(options["ssl"].verify_mode, ssl.CERT_REQUIRED)
        self.assertTrue(options["proxy"])
        self.assertTrue(options["additional_headers"]["Cookie"].startswith("muid="))

    def test_gec_token_uses_service_five_minute_time_bucket(self):
        self.assertEqual(tts._gec_token(1760000100), tts._gec_token(1760000399))
        self.assertNotEqual(tts._gec_token(1760000100), tts._gec_token(1760000400))

    def test_success_writes_only_audio_and_sends_english_female_ssml(self):
        socket = FakeWebsocket([
            "Path:turn.start\r\n\r\n{}",
            audio_frame(b"MP3-frame-1"),
            audio_frame(b"MP3-frame-2"),
            audio_frame(b"", content_type=None),
            "Path:turn.end\r\n\r\n",
        ])
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "voice.mp3"
            with self.options(), patch.object(tts, "_connect", return_value=socket):
                result = tts.synthesize("Hello & thank you <everyone>!", output)
            self.assertEqual(result, str(output))
            self.assertEqual(output.read_bytes(), b"MP3-frame-1MP3-frame-2")
            self.assertEqual(list(Path(directory).iterdir()), [output])
        self.assertTrue(socket.closed)
        ssml = socket.sent[1].split("\r\n\r\n", 1)[1]
        root = ElementTree.fromstring(ssml)
        self.assertEqual(tts.VOICE, "en-US-JennyNeural")
        self.assertEqual(root.attrib["{http://www.w3.org/XML/1998/namespace}lang"], "en-US")
        voice = root.find("{http://www.w3.org/2001/10/synthesis}voice")
        self.assertEqual(voice.attrib["name"], "Microsoft Server Speech Text to Speech Voice (en-US, JennyNeural)")
        self.assertIn("Hello & thank you <everyone>!", "".join(root.itertext()))
        self.assertIn("Path:speech.config", socket.sent[0])

    def test_multiple_chunks_have_separate_requests_and_append_audio_in_order(self):
        sockets = []
        def connector(*args, **kwargs):
            value = FakeWebsocket([
                audio_frame(str(len(sockets)).encode("ascii")),
                "Path:turn.end\r\n\r\n",
            ])
            sockets.append(value)
            return value
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "voice.mp3"
            with self.options(), patch.object(tts, "_connect", side_effect=connector):
                tts.synthesize("ế" * 5000, output)
            self.assertGreater(len(sockets), 1)
            self.assertEqual(output.read_bytes(), b"".join(str(n).encode() for n in range(len(sockets))))
        self.assertTrue(all(s.closed for s in sockets))

    def test_midstream_failure_preserves_existing_destination_and_removes_partial(self):
        socket = FakeWebsocket([audio_frame(b"partial"), ConnectionError("private detail")])
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "voice.mp3"
            output.write_bytes(b"previous")
            with self.options(), patch.object(tts, "_connect", return_value=socket):
                with self.assertRaisesRegex(tts.NarrationError, "kiểm tra Internet") as error:
                    tts.synthesize("Xin chào", output)
            self.assertNotIn("private detail", str(error.exception))
            self.assertEqual(output.read_bytes(), b"previous")
            self.assertEqual(list(Path(directory).iterdir()), [output])

    def test_cancellation_removes_partial_and_closes_connection(self):
        socket = FakeWebsocket([audio_frame(b"partial"), "Path:turn.end\r\n\r\n"])
        calls = 0
        def should_stop():
            nonlocal calls
            calls += 1
            return calls >= 4
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "voice.mp3"
            with self.options(), patch.object(tts, "_connect", return_value=socket):
                with self.assertRaises(tts.NarrationCancelled):
                    tts.synthesize("Xin chào", output, should_stop)
            self.assertEqual(list(Path(directory).iterdir()), [])
        self.assertTrue(socket.closed)

    def test_no_audio_and_bad_audio_frames_fail(self):
        socket = FakeWebsocket(["Path:turn.end\r\n\r\n"])
        with self.options(), patch.object(tts, "_connect", return_value=socket):
            with self.assertRaisesRegex(tts.NarrationError, "chưa trả về"):
                tts._stream_chunk("hello", io.BytesIO(), None, 0)
        for message in [b"", b"\x00\x40hi", audio_frame(b"data", path="not-audio"), audio_frame(b"x", content_type="text/plain")]:
            with self.assertRaises(tts.NarrationError):
                tts._audio_frame(message)

    def test_idle_receive_times_out(self):
        socket = FakeWebsocket([TimeoutError()])
        with self.options(), patch.object(tts, "_connect", return_value=socket), patch.object(tts.time, "monotonic", side_effect=[0.0, 0.1, 46.0]):
            with self.assertRaisesRegex(tts.NarrationError, "không phản hồi"):
                tts._stream_chunk("hello", io.BytesIO(), None, 0)

    def test_total_chunk_deadline_bounds_busy_but_unfinished_stream(self):
        socket = FakeWebsocket(["Path:audio.metadata\r\n\r\n{}"])
        with self.options(), patch.object(tts, "_connect", return_value=socket), patch.object(tts.time, "monotonic", side_effect=[0.0, 0.1, 1.0, 181.0]):
            with self.assertRaisesRegex(tts.NarrationError, "quá lâu"):
                tts._stream_chunk("hello", io.BytesIO(), None, 0)

    def test_unwritable_destination_has_clear_error_without_creating_file(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "missing-directory" / "voice.mp3"
            with self.assertRaisesRegex(tts.NarrationError, "Không tạo được tệp"):
                tts.synthesize("Xin chào", output)

    def test_http_403_clock_skew_retries_once_and_does_not_duplicate_partial(self):
        exception = RuntimeError("403")
        exception.response = types.SimpleNamespace(status_code=403, headers={"Date": "Sat, 01 Nov 2025 12:00:00 GMT"})
        calls = []
        def stream(text, destination, should_stop, skew):
            calls.append(skew)
            if len(calls) == 1:
                destination.write(b"discarded")
                raise exception
            destination.write(b"complete")
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "voice.mp3"
            with patch.object(tts, "_stream_chunk", side_effect=stream):
                tts.synthesize("Xin chào", output)
            self.assertEqual(output.read_bytes(), b"complete")
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0], 0)
        self.assertNotEqual(calls[1], 0)

    def test_non_clock_error_is_not_retried(self):
        with tempfile.TemporaryDirectory() as directory:
            with patch.object(tts, "_stream_chunk", side_effect=RuntimeError("denied")) as stream:
                with self.assertRaises(tts.NarrationError):
                    tts.synthesize("Xin chào", Path(directory) / "voice.mp3")
                self.assertEqual(stream.call_count, 1)


if __name__ == "__main__":
    unittest.main()
