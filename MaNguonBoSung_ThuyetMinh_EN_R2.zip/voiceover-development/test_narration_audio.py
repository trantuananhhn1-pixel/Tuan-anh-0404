import json
from pathlib import Path
import shutil
import subprocess
import tempfile
import types
import unittest
from unittest.mock import Mock, patch

import narration_audio as audio


class IntegrationTests(unittest.TestCase):
    def make_pipeline(self):
        generator = types.SimpleNamespace()
        generator._finish_video = Mock(return_value="original-result")

        def generate_all(rows, output_root="out", on_log=None, should_stop=None):
            sum(row.get("count", 1) for row in rows)
            results = []
            for row in rows:
                for index in range(row.get("count", 1)):
                    results.append(generator._finish_video(
                        "main", "big", "small", "arrow",
                        f"{output_root}/{row['id']}_{index}.mp4", "ffmpeg", "tmp", False,
                    ))
            return results

        def finish(main, title_big, title_small, arrow, out_path, ffmpeg_exe, tmp, style_random):
            return generator._original_finish(
                main, title_big, title_small, arrow, out_path, ffmpeg_exe, tmp, style_random,
            )

        generator._original_finish = generator._finish_video
        generator._finish_video = finish
        generator.generate_all = generate_all
        presenter = types.SimpleNamespace(generate_all=generate_all)
        synth = Mock(side_effect=lambda text, dest, **kw: Path(dest).write_bytes(b"MP3"))
        audio.install_audio(generator, presenter, synth)
        return generator, presenter, synth

    def test_blank_rows_use_original_output_and_no_speech(self):
        generator, presenter, synth = self.make_pipeline()
        rows = [{"id": "old", "count": 2}]
        with patch.object(audio, "mux_narration") as mux:
            result = presenter.generate_all(rows, "output")
        self.assertEqual(result, ["original-result"] * 2)
        synth.assert_not_called()
        mux.assert_not_called()
        self.assertEqual(generator._original_finish.call_args_list[0].args[4], "output/old_0.mp4")

    def test_mixed_rows_keep_alignment_and_cache_speech_per_text(self):
        generator, presenter, synth = self.make_pipeline()
        rows = [
            {"id": "a", "narration": "Xin chào", "count": 2},
            {"id": "b", "narration": ""},
            {"id": "c", "narration": "Nội dung riêng"},
        ]
        with patch.object(audio, "mux_narration") as mux:
            result = presenter.generate_all(rows)
        self.assertEqual(len(result), 4)
        self.assertEqual([c.args[0] for c in synth.call_args_list], ["Xin chào", "Nội dung riêng"])
        self.assertEqual([c.args[2] for c in mux.call_args_list], ["out/a_0.mp4", "out/a_1.mp4", "out/c_0.mp4"])
        self.assertEqual(generator._original_finish.call_args_list[2].args[4], "out/b_0.mp4")
        self.assertIsNone(getattr(audio._local, "state", None))

    def test_speech_failure_never_renders_or_muxes(self):
        generator, presenter, synth = self.make_pipeline()
        synth.side_effect = RuntimeError("dịch vụ không kết nối")
        with patch.object(audio, "mux_narration") as mux:
            with self.assertRaisesRegex(RuntimeError, "không kết nối"):
                presenter.generate_all([{"id": "a", "narration": "Xin chào"}])
        generator._original_finish.assert_not_called()
        mux.assert_not_called()
        self.assertIsNone(getattr(audio._local, "state", None))

    def test_cancellation_never_synthesizes(self):
        generator, presenter, synth = self.make_pipeline()
        with self.assertRaisesRegex(RuntimeError, "Đã dừng"):
            presenter.generate_all([{"id": "a", "narration": "Xin chào"}], should_stop=lambda: True)
        synth.assert_not_called()
        generator._original_finish.assert_not_called()

    def test_logs_received_narration_count_including_zero(self):
        generator, presenter, synth = self.make_pipeline()
        logs = []
        presenter.generate_all([{"id": "a"}], on_log=logs.append)
        self.assertIn("0/1 dòng có lời đọc", logs[0])
        self.assertIn("Không có nội dung", logs[1])
        synth.assert_not_called()
        logs.clear()
        with patch.object(audio, "mux_narration"):
            presenter.generate_all([{"id": "a", "narration": "Xin chào"}], on_log=logs.append)
        self.assertIn("1/1 dòng có lời đọc", logs[0])


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "FFmpeg required")
class FFmpegTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.video = self.root / "original.mp4"
        self.run_command("ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i",
                         "testsrc2=size=160x120:rate=25:duration=2", "-c:v", "libx264",
                         "-pix_fmt", "yuv420p", str(self.video))

    def run_command(self, *args):
        return subprocess.run(args, check=True, capture_output=True).stdout

    def video_hashes(self, path):
        result = json.loads(self.run_command(
            "ffprobe", "-v", "error", "-select_streams", "v:0", "-show_packets",
            "-show_data_hash", "sha256", "-show_entries", "packet=data_hash", "-of", "json", str(path),
        ))
        return [p["data_hash"] for p in result["packets"]]

    def check_audio_duration(self, seconds):
        speech = self.root / f"speech_{seconds}.mp3"
        output = self.root / f"final_{seconds}.mp4"
        self.run_command("ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i",
                         f"sine=frequency=440:duration={seconds}", str(speech))
        audio.mux_narration(self.video, speech, output, "ffmpeg")
        self.assertEqual(self.video_hashes(output), self.video_hashes(self.video))
        info = json.loads(self.run_command("ffprobe", "-v", "error", "-show_streams", "-of", "json", str(output)))
        self.assertEqual([s["codec_type"] for s in info["streams"]], ["video", "audio"])
        self.assertAlmostEqual(audio.probe_duration("ffmpeg", output), 2, delta=0.1)
        self.assertGreater(int(info["streams"][1]["nb_frames"]), 0)

    def test_shorter_speech_preserves_every_video_packet_and_duration(self):
        self.check_audio_duration(0.7)

    def test_longer_speech_preserves_every_video_packet_and_duration(self):
        self.check_audio_duration(5)

    def test_failed_audio_preserves_existing_output(self):
        output = self.root / "existing.mp4"
        output.write_bytes(b"original-user-output")
        with self.assertRaises(RuntimeError):
            audio.mux_narration(self.video, self.root / "missing.mp3", output, "ffmpeg")
        self.assertEqual(output.read_bytes(), b"original-user-output")
        self.assertFalse(list(self.root.glob(".narration_*")))

    def test_silent_audio_cannot_be_reported_as_successful_narration(self):
        silent = self.root / "silent.mp3"
        output = self.root / "final.mp4"
        self.run_command("ffmpeg", "-loglevel", "error", "-f", "lavfi", "-i",
                         "anullsrc=r=24000:cl=mono", "-t", "1", str(silent))
        with self.assertRaisesRegex(RuntimeError, "im lặng"):
            audio.mux_narration(self.video, silent, output, "ffmpeg")
        self.assertFalse(output.exists())
        self.assertFalse(list(self.root.glob(".narration_*")))


if __name__ == "__main__":
    unittest.main()
