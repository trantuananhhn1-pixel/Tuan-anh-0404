"""Reproduce the optional-narration build without altering the original EXE."""
from __future__ import annotations

import argparse
from pathlib import Path

from repack_pyinstaller import build_file


def make_hook(root):
    modules = [(name, (root / (name + ".py")).read_text(encoding="utf-8"))
               for name in ("narration_tts", "narration_ui", "narration_audio")]
    return (
        "import sys as _sys\n"
        "import types as _types\n"
        "# Preserve the original dedicated YouTube cookie-worker entry path.\n"
        "if '--cookie-worker' not in _sys.argv:\n"
        f"    for _name, _source in {modules!r}:\n"
        "        _module = _types.ModuleType(_name)\n"
        "        _module.__file__ = _name + '.py'\n"
        "        _sys.modules[_name] = _module\n"
        "        exec(compile(_source, _module.__file__, 'exec'), _module.__dict__)\n"
        "    _sys.modules['narration_ui'].install_ui()\n"
        "    _sys.modules['narration_audio'].install_audio()\n"
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    hook = root / "voiceover_extension.py"
    hook.write_text(make_hook(root), encoding="utf-8")
    print(build_file(args.original, hook, args.output, recompute_checksum=True))


if __name__ == "__main__":
    main()
